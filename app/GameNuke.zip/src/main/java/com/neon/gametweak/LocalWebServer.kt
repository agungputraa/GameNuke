package com.neon.gametweak

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder

class LocalWebServer private constructor(private val context: Context) {
    private var apiServerSocket: ServerSocket? = null
    private var webServerSocket: ServerSocket? = null

    var isApiRunning = false
        private set
    var isWebRunning = false
        private set

    private val coroutineScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, _ ->
            isApiRunning = false
            isWebRunning = false
        },
    )
    val documentRoot: File = File(context.getExternalFilesDir(null) ?: context.filesDir, "WebUI").apply { mkdirs() }
    val apiPort = 8080
    val webPort = 8081

    private val loopback: InetAddress = InetAddress.getByName("127.0.0.1")
    private val backlog = 50

    companion object {
        @Volatile
        private var instance: LocalWebServer? = null
        fun getInstance(context: Context): LocalWebServer = instance ?: synchronized(this) {
            instance ?: LocalWebServer(context).also { instance = it }
        }
    }

    fun startApiServer() {
        if (isApiRunning) return
        isApiRunning = true
        coroutineScope.launch {
            try {
                apiServerSocket = ServerSocket(apiPort, backlog, loopback)
                while (isApiRunning) {
                    val client = apiServerSocket?.accept() ?: break
                    launch { handleApiRequestStream(client) }
                }
            } catch (e: Exception) {
                isApiRunning = false
            }
        }
    }

    fun stopApiServer() {
        isApiRunning = false
        try { apiServerSocket?.close() } catch (ignored: Exception) {}
        apiServerSocket = null
    }

    fun startWebServer() {
        if (isWebRunning) return
        isWebRunning = true
        coroutineScope.launch {
            try {
                webServerSocket = ServerSocket(webPort, backlog, loopback)
                while (isWebRunning) {
                    val client = webServerSocket?.accept() ?: break
                    launch { handleStaticFileRequest(client) }
                }
            } catch (e: Exception) {
                isWebRunning = false
            }
        }
    }

    fun stopWebServer() {
        isWebRunning = false
        try { webServerSocket?.close() } catch (ignored: Exception) {}
        webServerSocket = null
    }

    private fun handleStaticFileRequest(client: Socket) {
        try {
            val reader = BufferedReader(InputStreamReader(client.getInputStream()))
            val out = client.getOutputStream()
            val requestLine = reader.readLine() ?: return

            while (true) {
                val headerLine = reader.readLine()
                if (headerLine.isNullOrEmpty()) break
            }

            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val pathRaw = parts[1]
            val path = URLDecoder.decode(pathRaw.split("?")[0], "UTF-8")

            val root = runCatching { documentRoot.canonicalFile }.getOrElse { documentRoot.absoluteFile }
            val relativePath = if (path == "/") "index.html" else path.trimStart('/')
            val file = runCatching { File(root, relativePath).canonicalFile }.getOrNull()
            val insideRoot = file != null && (file == root || file.path.startsWith(root.path + File.separator))
            if (!insideRoot || file == null || !file.exists() || file.isDirectory) {
                val notFound = "HTTP/1.1 404 Not Found\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n404 File Not Found"
                out.write(notFound.toByteArray())
                out.flush()
                return
            }

            val mimeType = when (file.extension.lowercase()) {
                "html" -> "text/html"
                "js" -> "application/javascript"
                "css" -> "text/css"
                "png" -> "image/png"
                "jpg", "jpeg" -> "image/jpeg"
                "json" -> "application/json"
                else -> "application/octet-stream"
            }

            val header = "HTTP/1.1 200 OK\r\nContent-Type: $mimeType\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n"
            out.write(header.toByteArray())
            file.inputStream().use { it.copyTo(out) }
            out.flush()
        } catch (ignored: Exception) {
        } finally {
            if (!isWebRunning || !client.isClosed) {
                try { client.close() } catch (ignored: Exception) {}
            }
        }
    }

    private fun handleApiRequestStream(client: Socket) {
        try {
            val reader = BufferedReader(InputStreamReader(client.getInputStream()))
            val out = client.getOutputStream()
            val requestLine = reader.readLine() ?: return

            val headers = mutableMapOf<String, String>()
            while (true) {
                val headerLine = reader.readLine()
                if (headerLine.isNullOrEmpty()) break
                val idx = headerLine.indexOf(':')
                if (idx > 0) headers[headerLine.substring(0, idx).trim().lowercase()] = headerLine.substring(idx + 1).trim()
            }

            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val pathRaw = parts[1]
            val path = URLDecoder.decode(pathRaw.split("?")[0], "UTF-8")

            if (path == "/api/stream") {
                try {
                    val header = "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-cache\r\nConnection: keep-alive\r\nAccess-Control-Allow-Origin: *\r\n\r\n"
                    out.write(header.toByteArray())
                    out.flush()

                    while (isApiRunning && !client.isClosed) {
                        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                        val memInfo = ActivityManager.MemoryInfo()
                        runCatching { am?.getMemoryInfo(memInfo) }
                        val ramTotal = memInfo.totalMem / (1024 * 1024)
                        val ramAvail = memInfo.availMem / (1024 * 1024)
                        val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                        val temp = (batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)?.toFloat() ?: 0f) / 10f

                        val json = "{\"ram_total\": $ramTotal, \"ram_avail\": $ramAvail, \"temp\": $temp}"
                        out.write(("data: $json\n\n").toByteArray())
                        out.flush()
                        Thread.sleep(1000)
                    }
                } catch (e: Exception) {}
                return
            }

            val adb = AdbManager.getInstance(context)
            val isOnline = runCatching { adb.isConnected() }.getOrDefault(false)

            val mutating = path in setOf("/api/kill", "/api/exec", "/api/trim", "/api/drop_caches", "/api/battery_reset")
            val origin = headers["origin"]
            val crossSite = headers["sec-fetch-site"] == "cross-site" ||
                (origin != null && !origin.startsWith("http://127.0.0.1") && !origin.startsWith("http://localhost"))
            if (mutating && crossSite) {
                sendJsonResponse(out, "{\"error\": \"Forbidden\"}")
                return
            }

            when (path) {
                "/api/ping" -> {
                    sendJsonResponse(out, "{\"status\": \"ok\", \"engine\": \"${if (isOnline) "online" else "offline"}\"}")
                }
                "/api/telemetry" -> {
                    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                    val memInfo = ActivityManager.MemoryInfo()
                    runCatching { am?.getMemoryInfo(memInfo) }
                    val ramTotal = memInfo.totalMem / (1024 * 1024)
                    val ramAvail = memInfo.availMem / (1024 * 1024)
                    var storageTotal = 0L
                    var storageAvail = 0L
                    try {
                        val statFs = StatFs(Environment.getDataDirectory().path)
                        storageTotal = statFs.totalBytes / (1024 * 1024)
                        storageAvail = statFs.availableBytes / (1024 * 1024)
                    } catch (e: Exception) {}
                    val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    val temp = (batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)?.toFloat() ?: 0f) / 10f
                    val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                    sendJsonResponse(out, "{\"ram_total_mb\": $ramTotal, \"ram_avail_mb\": $ramAvail, \"storage_total_mb\": $storageTotal, \"storage_avail_mb\": $storageAvail, \"temp_c\": $temp, \"battery_level\": $level}")
                }
                "/api/processes" -> {
                    if (!isOnline) { sendJsonResponse(out, "{\"error\": \"Engine Offline\"}"); return }
                    val result = adb.executeCommand("ps -A -o PID,RSS,NAME", "/", 5_000L, 64 * 1024)
                    if (!result.isSuccess) {
                        sendJsonResponse(out, "{\"error\": \"Process query failed\"}")
                        return
                    }
                    val jsonArray = StringBuilder("[")
                    var first = true
                    result.output.lineSequence().drop(1).forEach { row ->
                        val pParts = row.trim().split("\\s+".toRegex())
                        if (pParts.size >= 3) {
                            val pid = pParts[0]
                            val rss = pParts[1].toLongOrNull() ?: 0L
                            val name = pParts[2]
                            val memMb = rss / 1024
                            if (!name.contains("com.neon.gametweak") && !name.contains("ps") && !name.contains("sh") && memMb > 0) {
                                if (!first) jsonArray.append(",")
                                val safeName = name.replace("\\", "\\\\").replace("\"", "\\\"")
                                jsonArray.append("{\"pid\":\"$pid\", \"memory_mb\": $memMb, \"name\":\"$safeName\"}")
                                first = false
                            }
                        }
                    }
                    jsonArray.append("]")
                    sendJsonResponse(out, "{\"processes\": $jsonArray}")
                }
                "/api/kill" -> {
                    // A localhost HTTP endpoint must never expose arbitrary PID termination to
                    // another app/browser process. Keep process termination inside explicit UI.
                    sendJsonResponse(out, "{\"error\": \"Disabled in hardened API\"}")
                }
                "/api/trim" -> {
                    sendJsonResponse(out, "{\"error\": \"Disabled: use Android storage controls or Safe Cleaner\"}")
                }
                "/api/drop_caches" -> {
                    // Writing /proc/sys/vm/drop_caches is root-only on normal Android and is not a
                    // safe game-booster primitive. Do not report a fake success from shell transport.
                    sendJsonResponse(out, "{\"error\": \"Disabled: unsafe/unsupported operation\"}")
                }
                "/api/battery_reset" -> {
                    sendJsonResponse(out, "{\"error\": \"Disabled in hardened API\"}")
                }
                "/api/exec" -> {
                    sendJsonResponse(out, "{\"error\": \"Disabled: use structured in-app operations\"}")
                }
                else -> sendJsonResponse(out, "{\"error\": \"Endpoint not found. Refer to documentation.\"}")
            }
        } catch (ignored: Exception) {
        } finally {
            try { client.close() } catch (ignored: Exception) {}
        }
    }

    private fun sendJsonResponse(out: OutputStream, json: String) {
        val response = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nAccess-Control-Allow-Origin: *\r\n\r\n$json"
        out.write(response.toByteArray())
        out.flush()
    }
}
