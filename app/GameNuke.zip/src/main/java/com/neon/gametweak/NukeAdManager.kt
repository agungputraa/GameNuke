package com.neon.gametweak

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Revenue-optimized, gameplay-safe single-process AdMob coordinator.
 *
 * Design goals:
 * - keep navigation instant when an ad is not already loaded;
 * - never show a full-screen ad on every action;
 * - keep a global cooldown shared by app-open and interstitial ads;
 * - preload opportunistically instead of holding the user while an ad loads;
 * - keep every Google Mobile Ads load/show call on the main thread.
 */
object NukeAdManager {
    private const val TAG = "NukeAdManager"

    val APP_OPEN_ID: String get() = BuildConfig.ADMOB_APP_OPEN_ID
    val INTERSTITIAL_ID: String get() = BuildConfig.ADMOB_INTERSTITIAL_ID
    val BANNER_ID: String get() = BuildConfig.ADMOB_BANNER_ID

    private const val APP_OPEN_TIMEOUT_MS = 4L * 60L * 60L * 1_000L
    // Full-screen inventory is intentionally monetized harder than the old build, but only at
    // natural in-app transitions. It remains far below "every action" placement and never runs
    // while the gaming overlay is active.
    private const val MIN_TIME_BETWEEN_FULL_SCREEN_ADS_MS = 7L * 60L * 1_000L
    private const val MIN_TIME_BETWEEN_APP_OPEN_ADS_MS = 45L * 60L * 1_000L
    private const val MIN_SESSION_AGE_FOR_INTERSTITIAL_MS = 75L * 1_000L
    private const val NAVIGATION_CLICK_INTERVAL = 5
    private const val MIN_FOREGROUNDS_BEFORE_APP_OPEN = 4
    private const val GAMEPLAY_FULLSCREEN_GRACE_MS = 3L * 60L * 1_000L

    private const val ADS_PREFS = "NukeAdExperience"
    private const val KEY_FOREGROUND_COUNT = "foreground_count"
    private const val KEY_LAST_APP_OPEN_MS = "last_app_open_ms"
    private const val KEY_LAST_FULLSCREEN_MS = "last_fullscreen_ms"
    private const val KEY_LAST_GAMEPLAY_END_MS = "last_gameplay_end_ms"

    private val mainHandler = Handler(Looper.getMainLooper())
    private val processStartedAtElapsedMs = SystemClock.elapsedRealtime()

    @Volatile private var initialized = false
    @Volatile private var initializationStarted = false

    private var appOpenAd: AppOpenAd? = null
    private var appOpenLoadTimeMs = 0L
    private var appOpenLoading = false

    private var interstitialAd: InterstitialAd? = null
    private var interstitialLoading = false

    private var isShowingFullScreenAd = false
    private var navigationClickCount = 0
    private var lastFullScreenAdShowTimeMs = 0L

    private val suppressedActivityNames = setOf("SplashActivity", "GameLaunchSplashActivity")

    @Volatile var mainAppReady: Boolean = false

    private fun onMain(action: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) action() else mainHandler.post(action)
    }

    private fun adPrefs(context: Context) =
        context.applicationContext.getSharedPreferences(ADS_PREFS, Context.MODE_PRIVATE)

    private fun effectiveLastFullScreenMs(context: Context): Long {
        val persisted = adPrefs(context).safeLong(KEY_LAST_FULLSCREEN_MS, 0L)
        return maxOf(lastFullScreenAdShowTimeMs, persisted)
    }

    private fun markFullScreenShown(context: Context, appOpen: Boolean) {
        val now = System.currentTimeMillis()
        lastFullScreenAdShowTimeMs = now
        runCatching {
            val editor = adPrefs(context).edit().putLong(KEY_LAST_FULLSCREEN_MS, now)
            if (appOpen) editor.putLong(KEY_LAST_APP_OPEN_MS, now)
            editor.apply()
        }.onFailure { Log.w(TAG, "Unable to persist ad cadence", it) }
    }

    fun markGamingSessionEnded(context: Context) {
        runCatching {
            adPrefs(context).edit().putLong(KEY_LAST_GAMEPLAY_END_MS, System.currentTimeMillis()).apply()
        }
    }

    private fun fullScreenAllowed(context: Context): Boolean {
        if (NukeRuntimeState.state.value.overlayRunning) return false
        val lastEnd = adPrefs(context).safeLong(KEY_LAST_GAMEPLAY_END_MS, 0L)
        return lastEnd <= 0L || System.currentTimeMillis() - lastEnd >= GAMEPLAY_FULLSCREEN_GRACE_MS
    }

    private fun isAppOpenEligible(activity: Activity): Boolean {
        val prefs = adPrefs(activity)
        val count = prefs.safeInt(KEY_FOREGROUND_COUNT, 0)
        val next = if (count >= Int.MAX_VALUE - 1) Int.MAX_VALUE - 1 else count + 1
        runCatching { prefs.edit().putInt(KEY_FOREGROUND_COUNT, next).apply() }

        if (next < MIN_FOREGROUNDS_BEFORE_APP_OPEN) return false

        val lastOpen = prefs.safeLong(KEY_LAST_APP_OPEN_MS, 0L)
        return System.currentTimeMillis() - lastOpen >= MIN_TIME_BETWEEN_APP_OPEN_ADS_MS
    }

    fun initialize(context: Context) {
        val appContext = context.applicationContext
        onMain {
            if (initialized || initializationStarted) return@onMain
            if (!ConsentManager.canRequestAds()) {
                Log.d(TAG, "Mobile Ads initialization deferred until consent allows requests")
                return@onMain
            }

            initializationStarted = true
            try {
                if (BuildConfig.USE_TEST_ADS) {
                    MobileAds.setRequestConfiguration(
                        RequestConfiguration.Builder()
                            .setTestDeviceIds(listOf(AdRequest.DEVICE_ID_EMULATOR))
                            .build()
                    )
                }

                MobileAds.initialize(appContext) {
                    onMain {
                        initialized = true
                        initializationStarted = false
                        loadAppOpenInternal(appContext)
                        loadInterstitialInternal(appContext)
                    }
                }
            } catch (t: Throwable) {
                initializationStarted = false
                initialized = false
                Log.w(TAG, "Mobile Ads initialization failed", t)
            }
        }
    }

    fun preload(context: Context) {
        val appContext = context.applicationContext
        onMain {
            if (!ConsentManager.canRequestAds()) return@onMain
            if (!initialized) {
                initialize(appContext)
                return@onMain
            }
            loadAppOpenInternal(appContext)
            loadInterstitialInternal(appContext)
        }
    }

    fun loadAppOpen(context: Context) {
        val appContext = context.applicationContext
        onMain {
            if (!initialized) {
                initialize(appContext)
                return@onMain
            }
            loadAppOpenInternal(appContext)
        }
    }

    private fun loadAppOpenInternal(appContext: Context) {
        if (!ConsentManager.canRequestAds() || !initialized) return
        if (appOpenLoading || isAppOpenAdAvailable()) return

        appOpenLoading = true
        try {
            AppOpenAd.load(
                appContext,
                APP_OPEN_ID,
                AdRequest.Builder().build(),
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        appOpenAd = ad
                        appOpenLoadTimeMs = System.currentTimeMillis()
                        appOpenLoading = false
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        appOpenAd = null
                        appOpenLoading = false
                        Log.w(TAG, "App-open load failed: ${error.code} ${error.message}")
                    }
                },
            )
        } catch (t: Throwable) {
            appOpenLoading = false
            Log.w(TAG, "App-open load threw", t)
        }
    }

    fun showAppOpen(activity: Activity) = onMain { showAppOpenInternal(activity) }

    private fun showAppOpenInternal(activity: Activity) {
        if (!isActivityUsable(activity) || isShowingFullScreenAd || isSuppressedActivity(activity) || !fullScreenAllowed(activity)) return
        if (!mainAppReady || !ConsentManager.canRequestAds() || !isAppOpenEligible(activity)) return
        if (System.currentTimeMillis() - effectiveLastFullScreenMs(activity) < MIN_TIME_BETWEEN_FULL_SCREEN_ADS_MS) return

        val ad = appOpenAd
        if (!isAppOpenAdAvailable() || ad == null) {
            // Never interrupt the current foreground later because an ad finished loading late.
            loadAppOpenInternal(activity.applicationContext)
            return
        }

        appOpenAd = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                isShowingFullScreenAd = true
                markFullScreenShown(activity.applicationContext, appOpen = true)
            }

            override fun onAdDismissedFullScreenContent() {
                isShowingFullScreenAd = false
                loadAppOpenInternal(activity.applicationContext)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                isShowingFullScreenAd = false
                Log.w(TAG, "App-open show failed: ${error.code} ${error.message}")
                loadAppOpenInternal(activity.applicationContext)
            }
        }

        runCatching { ad.show(activity) }
            .onFailure {
                isShowingFullScreenAd = false
                Log.w(TAG, "App-open show threw", it)
                loadAppOpenInternal(activity.applicationContext)
            }
    }

    fun loadInterstitial(context: Context) {
        val appContext = context.applicationContext
        onMain {
            if (!initialized) {
                initialize(appContext)
                return@onMain
            }
            loadInterstitialInternal(appContext)
        }
    }

    private fun loadInterstitialInternal(appContext: Context) {
        if (!ConsentManager.canRequestAds() || !initialized) return
        if (interstitialLoading || interstitialAd != null) return

        interstitialLoading = true
        try {
            InterstitialAd.load(
                appContext,
                INTERSTITIAL_ID,
                AdRequest.Builder().build(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        interstitialAd = ad
                        interstitialLoading = false
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        interstitialAd = null
                        interstitialLoading = false
                        Log.w(TAG, "Interstitial load failed: ${error.code} ${error.message}")
                    }
                },
            )
        } catch (t: Throwable) {
            interstitialLoading = false
            Log.w(TAG, "Interstitial load threw", t)
        }
    }

    fun showInterstitial(activity: Activity, force: Boolean = false, onAdClosed: (() -> Unit)? = null) {
        val gate = OneShot(onAdClosed)
        onMain { showInterstitialInternal(activity, force, gate) }
    }

    private fun showInterstitialInternal(activity: Activity, force: Boolean, gate: OneShot) {
        if (!isActivityUsable(activity) || isShowingFullScreenAd || isSuppressedActivity(activity) ||
            !mainAppReady || !ConsentManager.canRequestAds() || !fullScreenAllowed(activity)
        ) {
            gate.run()
            return
        }

        if (SystemClock.elapsedRealtime() - processStartedAtElapsedMs < MIN_SESSION_AGE_FOR_INTERSTITIAL_MS) {
            gate.run()
            return
        }

        val now = System.currentTimeMillis()
        val cooldownFinished = now - effectiveLastFullScreenMs(activity) >= MIN_TIME_BETWEEN_FULL_SCREEN_ADS_MS
        if (!cooldownFinished) {
            gate.run()
            return
        }

        if (!force) {
            navigationClickCount = if (navigationClickCount >= Int.MAX_VALUE - 1) 1 else navigationClickCount + 1
            if (navigationClickCount % NAVIGATION_CLICK_INTERVAL != 0) {
                gate.run()
                if (interstitialAd == null) loadInterstitialInternal(activity.applicationContext)
                return
            }
        }

        val ad = interstitialAd
        if (ad == null) {
            // UX first: do not block navigation waiting for an ad network response.
            loadInterstitialInternal(activity.applicationContext)
            gate.run()
            return
        }

        interstitialAd = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                isShowingFullScreenAd = true
                markFullScreenShown(activity.applicationContext, appOpen = false)
            }

            override fun onAdDismissedFullScreenContent() {
                isShowingFullScreenAd = false
                loadInterstitialInternal(activity.applicationContext)
                gate.run()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                isShowingFullScreenAd = false
                Log.w(TAG, "Interstitial show failed: ${error.code} ${error.message}")
                loadInterstitialInternal(activity.applicationContext)
                gate.run()
            }
        }

        runCatching { ad.show(activity) }
            .onFailure {
                isShowingFullScreenAd = false
                Log.w(TAG, "Interstitial show threw", it)
                loadInterstitialInternal(activity.applicationContext)
                gate.run()
            }
    }

    /** Optional natural-pause hook. It still obeys the global cooldown and session grace period. */
    fun showInterstitialForEvent(activity: Activity, onAdClosed: (() -> Unit)? = null) {
        showInterstitial(activity, force = true, onAdClosed = onAdClosed)
    }

    private fun isAppOpenAdAvailable(): Boolean {
        val ageMs = System.currentTimeMillis() - appOpenLoadTimeMs
        return appOpenAd != null && appOpenLoadTimeMs > 0L && ageMs in 0 until APP_OPEN_TIMEOUT_MS
    }

    private fun isActivityUsable(activity: Activity): Boolean = !activity.isFinishing && !activity.isDestroyed

    private fun isSuppressedActivity(activity: Activity): Boolean = activity.javaClass.simpleName in suppressedActivityNames

    private class OneShot(private val action: (() -> Unit)?) {
        private val done = AtomicBoolean(false)

        fun run() {
            if (!done.compareAndSet(false, true)) return
            val task = action ?: return
            if (Looper.myLooper() == Looper.getMainLooper()) task() else mainHandler.post(task)
        }
    }
}
