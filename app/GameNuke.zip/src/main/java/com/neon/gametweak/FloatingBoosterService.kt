package com.neon.gametweak

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.BatteryManager
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * User-started, user-visible Game Nuke gaming cockpit.
 *
 * 3.8 from-zero floating rebuild goals:
 * - Fixed, low-overhead nuclear cockpit instead of a generic popup or Game Corner clone.
 * - Only real first-party tools are exposed; no decorative or remote-executable menu entries.
 * - Crosshair Studio, measured Deep Clean, verified FPS paths, Focus, Network Core and telemetry.
 * - Physics-based interaction plus contained Canvas effects without a full-HUD render loop.
 * - Shared preferences + runtime state keep the app and foreground cockpit synchronized.
 */
class FloatingBoosterService : Service() {
    companion object {
        const val ACTION_SHOW_OVERLAY = "com.neon.gametweak.action.SHOW_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.neon.gametweak.action.STOP_OVERLAY"
        const val EXTRA_USER_REQUESTED = "extra_user_requested"
        const val EXTRA_TARGET_PACKAGE = "extra_target_package"
        const val EXTRA_REVEAL_DELAY_MS = "extra_reveal_delay_ms"
        private const val TAG = "NukeCockpit"
        private const val PREFS = "NukePrefs"
        private const val K_ACTIVE = "overlay_active_session"
        private const val K_ACTIVE_PACKAGE = "overlay_active_package"
        private const val K_HUD_SCALE = "overlay_hud_scale"
        private const val K_HUD_ALPHA = "overlay_hud_alpha"
        private const val K_LANG = "hud_lang"
        private const val K_EDGE_DOCK = "overlay_edge_dock"
        private const val K_EDGE_FRACTION = "overlay_edge_fraction"
        private const val K_ADAPTIVE_GAME_MODE = "adaptive_game_mode"
        private const val K_ADAPTIVE_OWN_AWAKE = "adaptive_own_awake"
        private const val K_ADAPTIVE_OWN_NETWORK = "adaptive_own_network"
        private const val K_ADAPTIVE_OWN_OEM = "adaptive_own_oem"
        private const val TOUCH_DEBOUNCE_MS = 300L
    }

    private enum class EdgeDock { LEFT, RIGHT, TOP, BOTTOM }

    private data class WindowSlot(val view: View, val params: WindowManager.LayoutParams)
    private data class HudAction(
        val label: String,
        val danger: Boolean = false,
        val enabled: () -> Boolean = { true },
        val action: suspend () -> Unit,
    )

    private val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
        Log.e(TAG, "HUD coroutine failure", throwable)
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate + exceptionHandler)
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val windows = ConcurrentHashMap<String, WindowSlot>()
    private var engine: NukePerformanceEngine? = null
    private var targetPackage: String? = null
    private var activationJob: Job? = null
    private var telemetryJob: Job? = null
    private var auxTelemetryJob: Job? = null
    private var thermalJob: Job? = null
    private var sessionJob: Job? = null
    private var switchJob: Job? = null
    private var stopping = false
    private var lastActionAt = 0L
    private var monitorTouchThrough = false
    private var foregroundStarted = false
    private var lastPingMs: Long? = null
    private var pingMeasuring = false
    private var lastAutomaticAlert: String? = null
    private var batteryPercent: Int = -1
    private var batteryTempC: Float? = null
    private var networkLabel: String = "--"
    private var wifiRssiDbm: Int? = null
    private var wifiLinkMbps: Int? = null
    private var sessionStartedElapsed: Long = 0L
    private var sessionBatteryStartPercent: Int = -1
    private var sessionChargeStartUah: Int? = null

    private val preferenceListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == null) return@OnSharedPreferenceChangeListener
        scope.launch {
            when {
                key == K_LANG -> {
                    val code = validLanguage(prefs.safeString(K_LANG, "en"))
                    Tx.setLang(code)
                    publishRuntime(engine?.state?.value)
                    refreshLocalizedHud()
                }
                key.startsWith("cross_") -> {
                    syncCrosshairOverlay()
                    publishRuntime(engine?.state?.value)
                }
                key == K_HUD_ALPHA -> applyHudAlphaToOpenWindows()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        Tx.setLang(validLanguage(prefs.safeString(K_LANG, "en")))
        prefs.registerOnSharedPreferenceChangeListener(preferenceListener)
        publishRuntime(null)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_OVERLAY) {
            scope.launch { stopSession("USER STOP") }
            return START_NOT_STICKY
        }

        // Never rebuild a heavy overlay from a null/stale START_STICKY restart. A running
        // foreground service already survives a normal Recents swipe; new sessions must be explicit.
        if (intent?.action != ACTION_SHOW_OVERLAY ||
            !intent.getBooleanExtra(EXTRA_USER_REQUESTED, false)
        ) {
            rejectSessionStart(startId, "missing explicit user request")
            return START_NOT_STICKY
        }
        val pkg = intent.getStringExtra(EXTRA_TARGET_PACKAGE)?.trim()?.takeIf(::validPackage)
        if (pkg == null) {
            rejectSessionStart(startId, "invalid target package")
            return START_NOT_STICKY
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            rejectSessionStart(startId, "overlay permission unavailable")
            return START_NOT_STICKY
        }
        if (!ensureForegroundSession(pkg)) {
            rejectSessionStart(startId, "foreground service could not start")
            return START_NOT_STICKY
        }

        val revealDelay = intent?.getLongExtra(EXTRA_REVEAL_DELAY_MS, 0L)?.coerceIn(0L, 2_000L) ?: 0L
        switchJob?.cancel()
        switchJob = scope.launch {
            try {
                switchSession(pkg, revealDelay)
            } catch (error: Throwable) {
                Log.e(TAG, "Floating session bootstrap failed safely", error)
                NukeRuntimeState.setLaunchHandoffActive(false)
                cancelLoops()
                removeAllWindowsImmediate()
                withContext(Dispatchers.IO) { runCatching { engine?.restoreSession() } }
                restoreDisplayWithRetry(applicationContext)
                runCatching { engine?.releaseLocalResources() }
                engine = null
                targetPackage = null
                clearSessionMarker()
                NukeToast.error(applicationContext, "Floating session failed safely; session changes were restored", true)
                if (foregroundStarted) {
                    ServiceCompat.stopForeground(this@FloatingBoosterService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    foregroundStarted = false
                }
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // stopWithTask=false keeps the already-running user-visible FGS independent from the
        // MainActivity task. We intentionally do not ask Android to resurrect it after process death.
        publishRuntime(engine?.state?.value)
        super.onTaskRemoved(rootIntent)
    }

    private fun rejectSessionStart(startId: Int, reason: String) {
        NukeRuntimeState.setLaunchHandoffActive(false)
        clearSessionMarker()
        // Detached one-shot recovery scope: stopSelf() can destroy/cancel the service scope
        // immediately, so rollback must not be tied to this Service lifecycle. It only holds the
        // application Context and exits after this single restore attempt.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            val restore = runCatching { NukeDisplayProfileController.restoreIfOwned(applicationContext) }.getOrNull()
            if (restore?.outcome == NukeDisplayProfileController.Outcome.ERROR ||
                restore?.outcome == NukeDisplayProfileController.Outcome.DEFERRED
            ) {
                Log.w(TAG, "Display restore after rejected session: ${restore.message}")
            }
        }
        Log.w(TAG, "Rejected floating session start: $reason")
        stopSelf(startId)
    }

    private suspend fun switchSession(pkg: String, revealDelay: Long) {
        stopping = false
        val old = engine
        if (old != null && targetPackage != null && targetPackage != pkg) {
            cancelLoops()
            withTimeoutOrNull(4_000L) { runCatching { old.restoreSession() } }
            // Display size/density changes can invalidate overlay coordinates. Remove every window
            // before rollback, then let the next session recreate them against fresh WindowMetrics.
            removeAllWindowsImmediate()
            withContext(Dispatchers.IO) { runCatching { NukeDisplayProfileController.restoreIfOwned(applicationContext) } }
            old.releaseLocalResources()
            engine = null
            targetPackage = null
        }

        if (engine == null) {
            targetPackage = pkg
            captureSessionBatteryBaseline()
            engine = NukePerformanceEngine(applicationContext, pkg) { destination ->
                scope.launch(Dispatchers.Main.immediate) {
                    toastStatus("Opening $destination — return to Game Nuke when done", long = true)
                }
            }
        }
        prefs.edit().putBoolean(K_ACTIVE, true).putString(K_ACTIVE_PACKAGE, pkg).apply()
        NukeRuntimeState.setLaunchHandoffActive(false)
        publishRuntime(engine?.state?.value)
        startLoops(pkg)
        if (revealDelay > 0L) delay(revealDelay)
        ensureEdge()
        syncCrosshairOverlay()
        showNukeModeBanner()
    }

    private fun ensureForegroundSession(pkg: String): Boolean {
        val label = runCatching {
            val info = if (Build.VERSION.SDK_INT >= 33) {
                packageManager.getApplicationInfo(pkg, android.content.pm.PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION") packageManager.getApplicationInfo(pkg, 0)
            }
            packageManager.getApplicationLabel(info).toString()
        }.getOrDefault(pkg.substringAfterLast('.'))
        val notification = NukeSessionNotification.build(this, label)
        runCatching {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(
                    this,
                    NukeSessionNotification.NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
                )
            } else {
                @Suppress("DEPRECATION") startForeground(NukeSessionNotification.NOTIFICATION_ID, notification)
            }
            foregroundStarted = true
        }.onFailure {
            Log.e(TAG, "Unable to enter foreground gaming session", it)
            foregroundStarted = false
        }
        return foregroundStarted
    }

    private fun startLoops(pkg: String) {
        activationJob?.cancel(); telemetryJob?.cancel(); auxTelemetryJob?.cancel(); thermalJob?.cancel(); sessionJob?.cancel()
        val local = engine ?: return

        // First paint is independent from the heavier activation/probe path. This lets RAM/display
        // and an already-authorized CPU sample appear almost immediately when the overlay opens.
        telemetryJob = scope.launch {
            // Paint local RAM/display immediately; CPU follows on the next pass so a slow shell
            // endpoint cannot hold the entire HUD blank.
            runCatching { local.refreshHudMetrics(includeCpu = false) }
            local.state.value.let { updateTelemetryUi(it); publishRuntime(it) }
            runCatching { local.refreshHudMetrics(includeCpu = true) }
            local.state.value.let { updateTelemetryUi(it); publishRuntime(it) }
            while (isActive) {
                delay(1_100L)
                runCatching { local.refreshHudMetrics(includeCpu = true) }
                val state = local.state.value
                updateTelemetryUi(state)
                publishRuntime(state)
            }
        }
        // Battery/network/ping are intentionally decoupled from the expensive thermal + shell
        // metrics pass. A failed ping gets one quick retry and never holds CPU/RAM telemetry hostage.
        auxTelemetryJob = scope.launch {
            refreshAuxTelemetry(retryPing = true)
            engine?.state?.value?.let(::updateTelemetryUi)
            while (isActive) {
                delay(2_500L)
                refreshAuxTelemetry(retryPing = true)
                engine?.state?.value?.let(::updateTelemetryUi)
            }
        }
        activationJob = scope.launch(Dispatchers.IO) {
            runCatching { local.initializeAndActivate() }
                .onFailure { Log.e(TAG, "Core activation failed", it) }
            withContext(Dispatchers.Main.immediate) {
                local.state.value.let { updateTelemetryUi(it); publishRuntime(it) }
            }
        }
        thermalJob = scope.launch {
            delay(900L)
            while (isActive) {
                runCatching { local.refreshMetrics() }
                val state = local.state.value
                updateTelemetryUi(state)
                publishRuntime(state)
                delay(9_000L)
            }
        }
        sessionJob = scope.launch(Dispatchers.Default) {
            val result = OverlayGameSessionController(applicationContext, pkg).awaitSessionEnd()
            if (result.trackingAvailable && result.gameWasObserved) scope.launch { stopSession("GAME SESSION ENDED") }
        }
    }

    private fun cancelLoops() {
        activationJob?.cancel(); activationJob = null
        telemetryJob?.cancel(); telemetryJob = null
        auxTelemetryJob?.cancel(); auxTelemetryJob = null
        thermalJob?.cancel(); thermalJob = null
        sessionJob?.cancel(); sessionJob = null
    }

    private fun ensureEdge() {
        if (windows.containsKey("edge")) return
        val dock = runCatching {
            EdgeDock.valueOf(prefs.safeString(K_EDGE_DOCK, EdgeDock.LEFT.name))
        }.getOrDefault(EdgeDock.LEFT)
        val vertical = dock == EdgeDock.LEFT || dock == EdgeDock.RIGHT
        val view = LayoutInflater.from(this).inflate(
            if (vertical) R.layout.nuke_hud_edge else R.layout.nuke_hud_edge_horizontal,
            null,
        )
        val width = minOf(dp(if (vertical) 34 else 54), (screenWidth() * .94f).roundToInt())
        val height = minOf(dp(if (vertical) 54 else 34), (screenHeight() * .86f).roundToInt())
        val maxX = maxOf(0, screenWidth() - width)
        val maxY = maxOf(0, screenHeight() - height)
        val fraction = prefs.safeFloat(K_EDGE_FRACTION, .35f).takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: .35f
        val p = params(width, height).apply {
            x = when (dock) {
                EdgeDock.LEFT -> 0
                EdgeDock.RIGHT -> maxX
                EdgeDock.TOP, EdgeDock.BOTTOM -> (maxX * fraction).roundToInt().coerceIn(0, maxX)
            }
            y = when (dock) {
                EdgeDock.TOP -> 0
                EdgeDock.BOTTOM -> maxY
                EdgeDock.LEFT, EdgeDock.RIGHT -> (maxY * fraction).roundToInt().coerceIn(0, maxY)
            }
        }
        addWindow("edge", view, p)
        val edgeRoot = view.findViewById<View>(R.id.edgeRoot)
        makeDraggable(
            "edge",
            edgeRoot,
            tap = { openHub() },
            longPress = {
                toastOutcome("Ending Game Nuke session")
                scope.launch { stopSession("EDGE LONG PRESS") }
            },
        )
        applyKeepAwake()
        engine?.state?.value?.let(::updateTelemetryUi)
        refreshLocalizedHud()
    }

    private fun openHub() {
        if (windows.containsKey("hub")) { removeWindow("hub"); return }
        val view = LayoutInflater.from(this).inflate(R.layout.nuke_hud_hub, null)
        val width = scaledHubWidth()
        val height = scaledHubHeight()
        val p = params(width, height).apply {
            x = centeredX(width)
            y = (screenHeight() - height - dp(8)).coerceAtLeast(0)
        }
        addWindow("hub", view, p)
        configureHubTools(view)
        view.findViewById<View>(R.id.hubMinimize).safeClick { removeWindow("hub") }
        view.findViewById<View>(R.id.hubClose).safeClick {
            toastOutcome("Ending Game Nuke session")
            scope.launch { stopSession("HUD CLOSE") }
        }
        view.findViewById<View>(R.id.hubAllTools).safeClick { openFeatureCenter() }

        // Advanced controls get a child panel; simple booleans use a real native Switch in-place.
        view.findViewById<View>(R.id.hubAimResponse).safeClick { setHubActive(R.id.hubAimResponse); openAimResponse() }
        view.findViewById<View>(R.id.hubCrosshair).safeClick { setHubActive(R.id.hubCrosshair); openCrosshairStudio() }
        view.findViewById<View>(R.id.hubDeepClean).safeClick { setHubActive(R.id.hubDeepClean); openDeepClean() }
        view.findViewById<View>(R.id.hubMaxFps).safeClick { setHubActive(R.id.hubMaxFps); openMaxFps() }
        view.findViewById<View>(R.id.hubNetwork).safeClick { setHubActive(R.id.hubNetwork); openNetwork() }
        view.findViewById<View>(R.id.hubMonitor).safeClick { setHubActive(R.id.hubMonitor); openMonitor() }
        view.findViewById<View>(R.id.hubRadar).safeClick { setHubActive(R.id.hubRadar); openResourceRadar() }
        view.findViewById<View>(R.id.hubScreenControl).safeClick { setHubActive(R.id.hubScreenControl); openScreenControl() }
        view.findViewById<View>(R.id.hubBackgroundSweep).safeClick { runEngineAction { sweepSafeBackground() } }

        view.findViewById<NukeHudToggleView>(R.id.hubGameMode)?.setOnToggleRequested { requested ->
            setAdaptiveGameMode(requested)
        }
        view.findViewById<NukeHudToggleView>(R.id.hubDnd)?.setOnToggleRequested { requested ->
            val state = engine?.state?.value
            if (state?.dndAccess == true) runToggleAction(R.id.hubDnd) { setGameFocus(requested) }
            else {
                view.findViewById<NukeHudToggleView>(R.id.hubDnd)?.setCheckedSilently(false)
                toastStatus("Opening Do Not Disturb access settings — return to Game Nuke when done", long = true)
                runCatching { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
        }
        view.findViewById<NukeHudToggleView>(R.id.hubCallShield)?.setOnToggleRequested { requested ->
            when {
                !NukeCallShield.isSupported(this) -> {
                    view.findViewById<NukeHudToggleView>(R.id.hubCallShield)?.setCheckedSilently(false)
                    toastOutcome("Call Shield is not available on this Android build")
                }
                requested && !NukeCallShield.isRoleHeld(this) -> {
                    view.findViewById<NukeHudToggleView>(R.id.hubCallShield)?.setCheckedSilently(false)
                    toastStatus("Opening Call Shield role settings — choose Game Nuke, then return", long = true)
                    if (!NukeCallShield.requestRole(this)) toastOutcome("Call Shield permission screen could not be opened")
                }
                else -> {
                    val applied = NukeCallShield.setEnabled(this, requested)
                    view.findViewById<NukeHudToggleView>(R.id.hubCallShield)?.setCheckedSilently(applied && requested)
                    if (requested && !applied) toastOutcome("Call Shield failed to enable")
                    else toastOutcome(if (requested) "Call Shield enabled for gaming sessions" else "Call Shield disabled")
                }
            }
        }
        view.findViewById<NukeHudToggleView>(R.id.hubBatterySaver)?.setOnToggleRequested { requested ->
            runToggleAction(R.id.hubBatterySaver) { setBatterySaver(requested) }
        }
        view.findViewById<NukeHudToggleView>(R.id.hubDataSaver)?.setOnToggleRequested { requested ->
            runToggleAction(R.id.hubDataSaver) { setDataSaver(requested) }
        }
        view.findViewById<NukeHudToggleView>(R.id.hubNetworkBoost)?.setOnToggleRequested { requested ->
            runToggleAction(R.id.hubNetworkBoost) { setNetworkBoost(requested) }
        }

        view.findViewById<NukeReactorCoreView>(R.id.hubReactor)?.apply {
            setStatus(NukeReactorCoreView.Status.DEGRADED)
            safeClick {
                NukeMotionEngine.pop(this)
                scope.launch {
                    runCatching { engine?.initializeAndActivate() }
                    engine?.state?.value?.let { updateTelemetryUi(it); publishRuntime(it) }
                }
            }
        }
        applyKeepAwake()
        refreshLocalizedHud()
        engine?.state?.value?.let(::updateTelemetryUi)
    }

    private fun setAdaptiveGameMode(enabled: Boolean) {
        val toggle = windows["hub"]?.view?.findViewById<NukeHudToggleView>(R.id.hubGameMode)
        val local = engine
        if (local == null) {
            toggle?.setCheckedSilently(false)
            toastOutcome("Game Mode is not ready yet")
            return
        }
        toggle?.setBusy(true)
        scope.launch {
            if (enabled) {
                val wasAwake = prefs.safeBoolean("hud_keep_awake", false)
                prefs.edit()
                    .putBoolean(K_ADAPTIVE_GAME_MODE, true)
                    .putBoolean(K_ADAPTIVE_OWN_AWAKE, !wasAwake)
                    .apply()
                if (!wasAwake) {
                    prefs.edit().putBoolean("hud_keep_awake", true).apply()
                    applyKeepAwake()
                }
                var ownNetwork = false
                if (!local.state.value.networkBoostActive) {
                    runCatching { local.setNetworkBoost(true) }
                    ownNetwork = local.state.value.networkBoostActive
                }
                var ownOem = false
                val gameModeSupported = local.state.value.capabilities.firstOrNull { it.id == "game_mode" }?.supported == true
                if (gameModeSupported && local.state.value.gameModePerformance != true) {
                    runCatching { local.setPerformanceGameMode(true) }
                    ownOem = local.state.value.gameModePerformance == true
                }
                // Display-side path is capability-driven and session-owned. Unsupported layers simply no-op.
                runCatching { local.maximizeNativeFps() }
                prefs.edit().putBoolean(K_ADAPTIVE_OWN_NETWORK, ownNetwork).putBoolean(K_ADAPTIVE_OWN_OEM, ownOem).apply()
                toastOutcome("Adaptive Game Mode enabled • supported device layers applied")
            } else {
                val ownNetwork = prefs.safeBoolean(K_ADAPTIVE_OWN_NETWORK, false)
                val ownOem = prefs.safeBoolean(K_ADAPTIVE_OWN_OEM, false)
                val ownAwake = prefs.safeBoolean(K_ADAPTIVE_OWN_AWAKE, false)
                if (ownOem && local.state.value.gameModePerformance == true) runCatching { local.setPerformanceGameMode(false) }
                if (ownNetwork && local.state.value.networkBoostActive) runCatching { local.setNetworkBoost(false) }
                if (ownAwake) {
                    prefs.edit().putBoolean("hud_keep_awake", false).apply()
                    applyKeepAwake()
                }
                prefs.edit().putBoolean(K_ADAPTIVE_GAME_MODE, false)
                    .remove(K_ADAPTIVE_OWN_AWAKE).remove(K_ADAPTIVE_OWN_NETWORK).remove(K_ADAPTIVE_OWN_OEM).apply()
                toastOutcome("Adaptive Game Mode disabled")
            }
            local.state.value.let { updateTelemetryUi(it); publishRuntime(it) }
            toggle?.setBusy(false)
        }
    }

    private fun runEngineAction(block: suspend NukePerformanceEngine.() -> Unit) {
        val local = engine ?: run {
            toastOutcome("Game Nuke core is not ready")
            return
        }
        scope.launch {
            val result = runCatching { local.block() }
                .onFailure { Log.w(TAG, "Instant HUD action failed", it) }
            local.state.value.let { updateTelemetryUi(it); publishRuntime(it) }
            if (result.isFailure) toastOutcome("Action failed: ${result.exceptionOrNull()?.message ?: "unknown error"}")
            else toastOutcome(local.state.value.message)
        }
    }

    private fun runToggleAction(viewId: Int, block: suspend NukePerformanceEngine.() -> Unit) {
        val local = engine ?: run {
            windows["hub"]?.view?.findViewById<NukeHudToggleView>(viewId)?.setCheckedSilently(false)
            toastOutcome("Game Nuke core is not ready")
            return
        }
        val toggle = windows["hub"]?.view?.findViewById<NukeHudToggleView>(viewId)
        toggle?.setBusy(true)
        scope.launch {
            val result = runCatching { local.block() }.onFailure { Log.w(TAG, "HUD toggle failed", it) }
            runCatching { local.refreshHudMetrics(includeCpu = false) }
            local.state.value.let { updateTelemetryUi(it); publishRuntime(it) }
            toggle?.setBusy(false)
            if (result.isFailure) toastOutcome("Action failed: ${result.exceptionOrNull()?.message ?: "unknown error"}")
            else toastOutcome(local.state.value.message)
        }
    }

    private fun toastStatus(message: String, long: Boolean = false) {
        val text = userFacingStatus(message).trim().ifBlank { "Action completed" }
        windows["hub"]?.view?.findViewById<TextView>(R.id.hubStatus)?.text = text.take(132)
        Toast.makeText(applicationContext, text.take(180), if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    private fun toastOutcome(message: String) {
        val normalized = userFacingStatus(message).trim().ifBlank { "Action completed" }
        val prefix = when {
            normalized.contains("UNSUPPORTED", true) || normalized.contains("UNAVAILABLE", true) ||
                normalized.contains("REQUIRED", true) || normalized.contains("NOT AVAILABLE", true) ||
                normalized.contains("NOT READY", true) || normalized.contains("NOT SUPPORTED", true) ||
                normalized.contains("SKIPPED", true) || normalized.contains("NO SAFE", true) -> "UNSUPPORTED • "
            normalized.contains("FAILED", true) || normalized.contains("REJECTED", true) ||
                normalized.contains("ERROR", true) || normalized.contains("UNREADABLE", true) ||
                normalized.contains("SELECT AT LEAST", true) || normalized.contains("COULD NOT", true) ||
                normalized.contains("BLOCKED", true) || normalized.contains("PENDING", true) ||
                normalized.contains("TIMEOUT", true) || normalized.contains("DENIED", true) -> "ERROR • "
            else -> "SUCCESS • "
        }
        toastStatus(prefix + normalized)
    }

    private fun configureHubTools(hub: View) {
        data class ToolSpec(val id: Int, val icon: Int, val label: String, val interaction: NukeHudToolView.Interaction)
        val tools = listOf(
            ToolSpec(R.id.hubAimResponse, R.drawable.nuke_ic_aim_response, "Aim Response", NukeHudToolView.Interaction.PANEL),
            ToolSpec(R.id.hubCrosshair, R.drawable.nuke_ic_crosshair, Tx.t("Bidikan", "Crosshair"), NukeHudToolView.Interaction.PANEL),
            ToolSpec(R.id.hubDeepClean, R.drawable.nuke_ic_clean, Tx.t("Bersih", "Deep Clean"), NukeHudToolView.Interaction.PANEL),
            ToolSpec(R.id.hubMaxFps, R.drawable.nuke_ic_speed, "FPS Max", NukeHudToolView.Interaction.PANEL),
            ToolSpec(R.id.hubNetwork, R.drawable.nuke_ic_network, Tx.t("Jaringan", "Network"), NukeHudToolView.Interaction.PANEL),
            ToolSpec(R.id.hubMonitor, R.drawable.nuke_ic_monitor, Tx.t("Monitor", "Monitor"), NukeHudToolView.Interaction.PANEL),
            ToolSpec(R.id.hubRadar, R.drawable.nuke_ic_radar, "Pressure Radar", NukeHudToolView.Interaction.PANEL),
            ToolSpec(R.id.hubBackgroundSweep, R.drawable.nuke_ic_background_sweep, "BG Sweep", NukeHudToolView.Interaction.ACTION),
            ToolSpec(R.id.hubScreenControl, R.drawable.nuke_ic_screen_control, "Screen", NukeHudToolView.Interaction.PANEL),
        )
        tools.forEach { spec ->
            hub.findViewById<NukeHudToolView>(spec.id)?.apply {
                setIconResource(spec.icon); setLabel(spec.label); setInteraction(spec.interaction)
            }
        }
        data class ToggleSpec(val id: Int, val icon: Int, val label: String)
        listOf(
            ToggleSpec(R.id.hubGameMode, R.drawable.nuke_ic_game_mode, "Game Mode"),
            ToggleSpec(R.id.hubDnd, R.drawable.nuke_ic_dnd, "Do Not Disturb"),
            ToggleSpec(R.id.hubCallShield, R.drawable.nuke_ic_call_shield, "Call Shield"),
            ToggleSpec(R.id.hubBatterySaver, R.drawable.nuke_ic_battery_saver, "Battery Saver"),
            ToggleSpec(R.id.hubDataSaver, R.drawable.nuke_ic_data_saver, "Data Saver"),
            ToggleSpec(R.id.hubNetworkBoost, R.drawable.nuke_ic_network_boost, "Net Boost"),
        ).forEach { spec ->
            hub.findViewById<NukeHudToggleView>(spec.id)?.apply { setIconResource(spec.icon); setLabel(spec.label) }
        }
        hub.findViewById<NukeSpeedometerView>(R.id.gaugeCpu)?.setLabel("CPU")
        hub.findViewById<NukeSpeedometerView>(R.id.gaugeRam)?.setLabel("RAM")
    }

    private val hubPanelToolIds = intArrayOf(
        R.id.hubAimResponse, R.id.hubCrosshair, R.id.hubDeepClean, R.id.hubMaxFps,
        R.id.hubNetwork, R.id.hubMonitor, R.id.hubRadar, R.id.hubBackgroundSweep, R.id.hubScreenControl,
    )

    private fun setHubActive(id: Int?) {
        val hub = windows["hub"]?.view ?: return
        hubPanelToolIds.forEach { toolId ->
            hub.findViewById<NukeHudToolView>(toolId)?.isActivated = id != null && toolId == id
        }
    }

    private fun openAimResponse() {
        val key = "aim_response"
        if (windows.containsKey(key)) { removeWindow(key); return }
        val view = moduleView("AIM RESPONSE", "SAFE DISPLAY + TOUCH RESPONSE PROFILE")
        val content = view.findViewById<LinearLayout>(R.id.moduleActions)
        content.addView(noteText("Universal device-side response tuning. It does not automate aiming or modify game files. Resolution/density tuning now lives in Graphics Engine so one crash-safe controller owns the whole display state."))
        content.addView(actionButton("OPEN GRAPHICS ENGINE") {
            removeWindow(key)
            openGraphicsEngine()
        })

        val centerDotAssist = Switch(this).apply {
            text = "Crosshair overlay"
            isChecked = prefs.safeBoolean("cross_en", false)
            styleSwitch(this)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("cross_en", checked).apply(); syncCrosshairOverlay()
                toastOutcome("Crosshair overlay ${if (checked) "enabled" else "disabled"}")
            }
        }
        content.addView(centerDotAssist)
        content.addView(actionButton("MAXIMIZE NATIVE DISPLAY RESPONSE") {
            if (!acceptAction()) return@actionButton
            runEngineAction { maximizeNativeFps() }
        })
        content.addView(actionButton("OPEN CROSSHAIR STUDIO") {
            removeWindow(key); setHubActive(R.id.hubCrosshair); openCrosshairStudio()
        })
        bindModuleWindow(key, view, x = dp(16), y = dp(54))
    }

    private fun openResourceRadar() {
        val key = "resource_radar"
        if (windows.containsKey(key)) { removeWindow(key); return }
        val view = moduleView("PRESSURE RADAR", "CPU • MEMORY • THERMAL HOTSPOTS")
        val content = view.findViewById<LinearLayout>(R.id.moduleActions)
        val status = view.findViewById<TextView>(R.id.moduleStatus)
        val target = targetPackage ?: return
        val radar = NukeResourceRadar(this, NukeGamingShellGateway(AdbManager.getInstance(applicationContext)), target)
        content.addView(noteText("Radar only reports measured background pressure. Killing is always manual, uses Android's background kill path, and protects the active game, Game Nuke, launchers and critical system packages."))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        fun render(snapshot: NukeResourceRadar.Snapshot) {
            status.text = snapshot.note.uppercase(Locale.US)
            list.removeAllViews()
            if (snapshot.items.isEmpty()) {
                list.addView(noteText("Process-level radar data is not available on this device right now. Core CPU/RAM/thermal telemetry remains active."))
                return
            }
            snapshot.items.forEach { item ->
                val cpuText = item.cpuPercent?.let { String.format(Locale.US, "%.1f%%", it) } ?: "--"
                val ramText = item.rssMb?.let { "${it}MB" } ?: "--"
                val title = item.packageName.substringAfterLast('.').take(28)
                val sub = "CPU $cpuText  •  RAM $ramText${if (item.protected) "  •  PROTECTED" else ""}"
                val tile = NukeActionTileView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50)).apply { bottomMargin = dp(4) }
                    configure(title, sub, R.drawable.nuke_ic_radar, danger = !item.protected && (item.cpuPercent ?: 0f) >= 25f)
                    isEnabled = !item.protected
                    alpha = if (item.protected) .55f else 1f
                    setOnClickListener {
                        if (!acceptAction() || item.protected) return@setOnClickListener
                        scope.launch(Dispatchers.IO) {
                            val result = runCatching { radar.kill(item.packageName) }.getOrElse { NukeCommandResult(-1, it.javaClass.simpleName) }
                            withContext(Dispatchers.Main.immediate) {
                                status.text = if (result.isSuccess) "BACKGROUND PROCESS RELEASE REQUESTED" else "PROCESS LEFT UNCHANGED"
                                toastOutcome(if (result.isSuccess) "Background process release requested" else "Background process release rejected")
                                view.postDelayed({
                                    scope.launch(Dispatchers.IO) {
                                        val next = runCatching { radar.scan() }.getOrNull()
                                        if (next != null) withContext(Dispatchers.Main.immediate) { render(next) }
                                    }
                                }, 650L)
                            }
                        }
                    }
                }
                list.addView(tile)
            }
        }

        content.addView(actionButton("REFRESH RADAR") {
            if (!acceptAction()) return@actionButton
            status.text = "SCANNING DEVICE PRESSURE…"
            scope.launch(Dispatchers.IO) {
                val snapshot = runCatching { radar.scan() }.getOrNull()
                withContext(Dispatchers.Main.immediate) {
                    if (snapshot == null) status.text = "RADAR DATA UNAVAILABLE" else render(snapshot)
                }
            }
        })
        bindModuleWindow(key, view, x = dp(18), y = dp(52))
        scope.launch(Dispatchers.IO) {
            val snapshot = runCatching { radar.scan() }.getOrNull()
            withContext(Dispatchers.Main.immediate) {
                if (snapshot == null) status.text = "RADAR DATA UNAVAILABLE" else render(snapshot)
            }
        }
    }

    private fun openScreenControl() {
        val key = "screen_control"
        if (windows.containsKey(key)) { removeWindow(key); return }
        val view = moduleView("SCREEN CONTROL", "ORIENTATION • AWAKE • HUD COMFORT")
        val content = view.findViewById<LinearLayout>(R.id.moduleActions)
        val rotation = Switch(this).apply {
            text = "Lock game rotation"
            isChecked = engine?.state?.value?.rotationLocked == true
            styleSwitch(this)
            setOnCheckedChangeListener { _, checked -> runEngineAction { setRotationLock(checked) } }
        }
        val awake = Switch(this).apply {
            text = "Keep screen awake while gaming"
            isChecked = prefs.safeBoolean("hud_keep_awake", false)
            styleSwitch(this)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("hud_keep_awake", checked).apply(); applyKeepAwake()
                toastOutcome("Keep screen awake ${if (checked) "enabled" else "disabled"}")
            }
        }
        content.addView(rotation); content.addView(awake)
        content.addView(seekControl("HUD OPACITY", 72, 98, (prefs.safeFloat(K_HUD_ALPHA, .96f) * 100).roundToInt()) {
            prefs.edit().putFloat(K_HUD_ALPHA, it / 100f).apply(); applyHudAlphaToOpenWindows()
        })
        content.addView(actionButton("OPEN GRAPHICS ENGINE") {
            removeWindow(key)
            openGraphicsEngine()
        })
        content.addView(actionButton("RESTORE ALL SESSION CHANGES") {
            if (!acceptAction()) return@actionButton
            val local = engine
            if (local == null) {
                toastOutcome("Game Nuke core is not ready")
                return@actionButton
            }
            val reopenHub = windows.containsKey("hub")
            scope.launch {
                val coreResult = runCatching { local.restoreSession() }
                // Never resize/re-density a display under attached overlay windows.
                removeAllWindowsImmediate()
                val displayResult = withContext(Dispatchers.IO) {
                    NukeDisplayProfileController.restoreIfOwned(applicationContext)
                }
                delay(180L)
                ensureEdge()
                syncCrosshairOverlay()
                if (reopenHub) openHub()
                local.state.value.let { updateTelemetryUi(it); publishRuntime(it) }
                when {
                    coreResult.isFailure -> toastOutcome("Restore failed: ${coreResult.exceptionOrNull()?.message ?: "unknown error"}")
                    displayResult.outcome == NukeDisplayProfileController.Outcome.ERROR -> NukeToast.error(applicationContext, displayResult.message, true)
                    displayResult.outcome == NukeDisplayProfileController.Outcome.DEFERRED -> NukeToast.error(applicationContext, displayResult.message, true)
                    else -> toastOutcome("All Game Nuke session changes restored")
                }
            }
        })
        content.addView(noteText("Rotation control is capability-probed and restored only when Game Nuke still owns the setting. Screen-awake affects only the active gaming overlay session. Restore All rolls back Game Nuke-owned session changes without force-stopping the game."))
        bindModuleWindow(key, view, x = dp(22), y = dp(62))
    }

    private fun openMaxFps() = openModule(
        "max_fps", "NATIVE FPS MAXIMIZER", "MAX PANEL PATH // NOT A GAME FPS UNLOCK",
        listOf(
            HudAction("MAXIMIZE VERIFIED FPS PATH") { engine?.maximizeNativeFps() },
            HudAction("MEASURE REAL GAME FPS") { engine?.sampleActualGameFps() },
            HudAction("GPU RELIEF 90") { engine?.toggleGpuRelief() },
            HudAction("ART PRIME") { engine?.primeGameArt() },
            HudAction("RE-PROBE DEVICE") { engine?.probeCapabilities() },
        ),
    )

    private fun openDeepClean() {
        val key = "deep_clean"
        if (windows.containsKey(key)) { removeWindow(key); return }
        val view = moduleView("DEEP CLEAN", "MEASURED CACHE + MEMORY RECLAIM")
        val metrics = view.findViewById<LinearLayout>(R.id.moduleMetrics)
        val fx = NukeCleanerFxView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(86)).apply { bottomMargin = dp(5) }
        }
        metrics.addView(fx)
        val content = view.findViewById<LinearLayout>(R.id.moduleActions)
        val ownCache = CheckBox(this).apply { text = "Game Nuke cache"; isChecked = true; styleCheck(this) }
        val ram = CheckBox(this).apply { text = "Pressure-aware RAM reclaim"; isChecked = true; styleCheck(this) }
        val storage = CheckBox(this).apply { text = "Bounded package cache trim"; isChecked = true; styleCheck(this) }
        val background = CheckBox(this).apply { text = "Android safe cached-process sweep"; isChecked = false; styleCheck(this) }
        content.addView(ownCache); content.addView(ram); content.addView(storage); content.addView(background)
        content.addView(noteText("Deep Clean uses measured cache/RAM operations. Background Sweep uses Android ActivityManager's safe-to-kill cached-process path; it never force-stops the foreground game."))
        content.addView(actionButton("START DEEP CLEAN") {
            if (!acceptAction()) return@actionButton
            scope.launch { runDeepClean(ownCache.isChecked, ram.isChecked, storage.isChecked, background.isChecked, view, fx) }
        })
        bindModuleWindow(key, view, x = dp(26), y = dp(76))
    }

    private suspend fun runDeepClean(
        clearOwnCache: Boolean,
        reclaimRam: Boolean,
        trimStorage: Boolean,
        sweepBackground: Boolean,
        view: View,
        fx: NukeCleanerFxView,
    ) {
        val status = view.findViewById<TextView>(R.id.moduleStatus)
        if (!clearOwnCache && !reclaimRam && !trimStorage && !sweepBackground) {
            status.text = "SELECT AT LEAST ONE CLEANING LAYER"
            toastOutcome("Select at least one cleaning layer")
            return
        }
        fx.startCleaning()
        status.text = "CLEANING // MEASURING BEFORE + AFTER"
        var ownGainMb = 0L
        try {
            if (clearOwnCache) {
                ownGainMb = withContext(Dispatchers.IO) {
                    val before = directoryBytes(cacheDir)
                    cacheDir.listFiles()?.forEach { runCatching { it.deleteRecursively() } }
                    val after = directoryBytes(cacheDir)
                    ((before - after) / (1024L * 1024L)).coerceAtLeast(0L)
                }
            }
            if (reclaimRam) runCatching { engine?.deepReclaim() }
            if (trimStorage) runCatching { engine?.trimCachesForStoragePressure() }
            if (sweepBackground) runCatching { engine?.sweepSafeBackground() }
            runCatching { engine?.refreshMetrics() }
            val state = engine?.state?.value
            val details = buildList {
                if (clearOwnCache) add("CACHE +${ownGainMb}MB")
                if (reclaimRam) add("RAM +${state?.lastMemoryGainMb ?: 0}MB")
                if (trimStorage) add("STORAGE +${state?.lastCacheGainMb ?: 0}MB")
                if (sweepBackground) add("BG SWEEP")
            }
            status.text = "CLEAN COMPLETE // ${details.joinToString(" // ")}"
            toastOutcome("Deep Clean complete • ${details.joinToString(" • ")}")
            state?.let { updateTelemetryUi(it); publishRuntime(it) }
        } finally {
            fx.stopCleaning()
        }
    }

    private fun openCrosshairStudio() {
        val key = "crosshair_studio"
        if (windows.containsKey(key)) { removeWindow(key); return }
        val view = moduleView("CROSSHAIR STUDIO", "RESTORED // NON-TOUCHABLE GAME OVERLAY")
        val content = view.findViewById<LinearLayout>(R.id.moduleActions)

        val enabled = Switch(this).apply {
            text = "Enable crosshair overlay"
            isChecked = prefs.safeBoolean("cross_en", false)
            styleSwitch(this)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("cross_en", checked).apply()
                syncCrosshairOverlay()
                toastOutcome("Crosshair overlay ${if (checked) "enabled" else "disabled"}")
            }
        }
        content.addView(enabled)
        val preview = NukeCrosshairView(this).apply {
            enabledCrosshair = true
            style = NukeCrosshairView.Style.values()[prefs.safeInt("cross_type", 1).coerceIn(0, 3)]
            crosshairColor = prefs.safeInt("cross_color", NukeHudPalette.Green)
            sizeDp = prefs.safeInt("cross_size", 22).toFloat()
            gapDp = prefs.safeInt("cross_gap", 6).toFloat()
            thicknessDp = prefs.safeInt("cross_thickness", 2).toFloat()
            opacity = prefs.safeInt("cross_opacity", 95) / 100f
            centerDot = prefs.safeBoolean("cross_dot", true)
            outline = prefs.safeBoolean("cross_outline", true)
            background = getDrawable(R.drawable.nuke_hud_glass)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(112)).apply { bottomMargin = dp(6) }
        }
        content.addView(preview)

        content.addView(controlTitle("STYLE"))
        val styles = listOf("DOT", "CROSS", "CIRCLE", "TACTIC")
        val styleSpinner = spinner(styles, prefs.safeInt("cross_type", 1).coerceIn(0, styles.lastIndex)) { index ->
            prefs.edit().putInt("cross_type", index).apply(); preview.style = NukeCrosshairView.Style.values()[index]; syncCrosshairOverlay()
        }
        content.addView(styleSpinner)

        content.addView(controlTitle("COLOR"))
        val colorNames = listOf("Nuke Green", "Red", "Amber", "Magenta", "White", "Cyan")
        val colors = intArrayOf(
            NukeHudPalette.Green, Color.rgb(255, 82, 82), Color.rgb(255, 193, 7),
            Color.rgb(230, 65, 160), Color.WHITE, Color.rgb(64, 210, 235),
        )
        val currentColor = prefs.safeInt("cross_color", colors[0])
        val colorIndex = colors.indexOf(currentColor).takeIf { it >= 0 } ?: 0
        content.addView(spinner(colorNames, colorIndex) { index -> prefs.edit().putInt("cross_color", colors[index]).apply(); preview.crosshairColor = colors[index]; syncCrosshairOverlay() })

        content.addView(seekControl("SIZE", 8, 64, prefs.safeInt("cross_size", 22)) { prefs.edit().putInt("cross_size", it).apply(); preview.sizeDp = it.toFloat(); syncCrosshairOverlay() })
        content.addView(seekControl("CENTER GAP", 0, 28, prefs.safeInt("cross_gap", 6)) { prefs.edit().putInt("cross_gap", it).apply(); preview.gapDp = it.toFloat(); syncCrosshairOverlay() })
        content.addView(seekControl("THICKNESS", 1, 6, prefs.safeInt("cross_thickness", 2)) { prefs.edit().putInt("cross_thickness", it).apply(); preview.thicknessDp = it.toFloat(); syncCrosshairOverlay() })
        content.addView(seekControl("OPACITY", 20, 100, prefs.safeInt("cross_opacity", 95)) { prefs.edit().putInt("cross_opacity", it).apply(); preview.opacity = it / 100f; syncCrosshairOverlay() })
        content.addView(seekControl("X OFFSET", -300, 300, prefs.safeInt("cross_x", 0)) { prefs.edit().putInt("cross_x", it).apply(); syncCrosshairOverlay() })
        content.addView(seekControl("Y OFFSET", -300, 300, prefs.safeInt("cross_y", 0)) { prefs.edit().putInt("cross_y", it).apply(); syncCrosshairOverlay() })

        val dot = CheckBox(this).apply {
            text = "Center dot"
            isChecked = prefs.safeBoolean("cross_dot", true)
            styleCheck(this)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("cross_dot", checked).apply(); preview.centerDot = checked; syncCrosshairOverlay(); toastOutcome("Crosshair center dot ${if (checked) "enabled" else "disabled"}") }
        }
        val outline = CheckBox(this).apply {
            text = "Dark contrast outline"
            isChecked = prefs.safeBoolean("cross_outline", true)
            styleCheck(this)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("cross_outline", checked).apply(); preview.outline = checked; syncCrosshairOverlay(); toastOutcome("Crosshair outline ${if (checked) "enabled" else "disabled"}") }
        }
        content.addView(dot); content.addView(outline)
        content.addView(actionButton("RESET CROSSHAIR") {
            if (!acceptAction()) return@actionButton
            prefs.edit()
                .putInt("cross_type", 1).putInt("cross_color", colors[0])
                .putInt("cross_size", 22).putInt("cross_gap", 6).putInt("cross_thickness", 2)
                .putInt("cross_opacity", 95).putInt("cross_x", 0).putInt("cross_y", 0)
                .putBoolean("cross_dot", true).putBoolean("cross_outline", true).apply()
            toastOutcome("Crosshair settings reset")
            removeWindow(key); openCrosshairStudio()
        })
        bindModuleWindow(key, view, x = dp(18), y = dp(54))
        syncCrosshairOverlay()
    }

    private fun openNetwork() {
        val key = "network"
        if (windows.containsKey(key)) { removeWindow(key); return }
        val view = moduleView("NETWORK CONTROL", "LATENCY • WIFI LINK • RECOVERY")
        val metrics = view.findViewById<LinearLayout>(R.id.moduleMetrics)
        val ping = metricLine("PING", lastPingMs?.let { "${it}ms" } ?: if (pingMeasuring) "MEASURING…" else "--")
        val signal = metricLine("WI-FI SIGNAL", wifiRssiDbm?.let { "${it} dBm" } ?: "UNAVAILABLE")
        val link = metricLine("LINK SPEED", wifiLinkMbps?.let { "${it} Mbps" } ?: "UNAVAILABLE")
        metrics.addView(ping); metrics.addView(signal); metrics.addView(link)
        val actions = view.findViewById<LinearLayout>(R.id.moduleActions)
        actions.addView(noteText("Wi-Fi RSSI/link speed use Android's in-process Wi-Fi API. Missing/redacted OEM values are reported as unavailable; Game Nuke does not request location just to fake a reading."))
        actions.addView(actionButton("REFRESH NETWORK STATUS") {
            if (!acceptAction()) return@actionButton
            scope.launch {
                refreshAuxTelemetry(retryPing = true)
                ping.text = "PING  ${lastPingMs?.let { "${it}ms" } ?: "UNAVAILABLE"}"
                signal.text = "WI-FI SIGNAL  ${wifiRssiDbm?.let { "${it} dBm" } ?: "UNAVAILABLE"}"
                link.text = "LINK SPEED  ${wifiLinkMbps?.let { "${it} Mbps" } ?: "UNAVAILABLE"}"
                toastOutcome("Network telemetry refreshed")
            }
        })
        actions.addView(actionButton("VERIFY CONNECTION") {
            if (!acceptAction()) return@actionButton
            scope.launch(Dispatchers.IO) {
                val ok = AdbManager.getInstance(applicationContext).ensurePersistentCore()
                withContext(Dispatchers.Main) { toastOutcome(if (ok) "Device connection verified" else "Device connection unavailable") }
            }
        })
        actions.addView(actionButton("SMART RECONNECT") {
            if (!acceptAction()) return@actionButton
            AdbManager.getInstance(applicationContext).initServer()
            toastOutcome("Smart reconnect requested")
        })
        actions.addView(actionButton("OPEN ANDROID NETWORK PANEL") {
            if (!acceptAction()) return@actionButton
            engine?.openInternetPanel()
        })
        bindModuleWindow(key, view, x = dp(18), y = dp(54))
    }

    private fun openFeatureCenter() {
        val key = "feature_center"
        if (windows.containsKey(key)) { removeWindow(key); return }
        data class FeatureSpec(
            val title: String,
            val subtitle: String,
            val category: String,
            val icon: Int,
            val capability: String? = null,
            val fallbackSupported: () -> Boolean = { true },
            val action: () -> Unit,
        )
        val view = moduleView("FEATURE CENTER", "SEARCH • CATEGORIES • DEVICE-AWARE")
        val status = view.findViewById<TextView>(R.id.moduleStatus)
        val actions = view.findViewById<LinearLayout>(R.id.moduleActions)
        actions.addView(noteText("Scalable tool catalog: the cockpit keeps only high-frequency favorites. New components live here, grouped and searchable, so small phones do not collapse into a crowded icon grid."))
        val search = EditText(this).apply {
            hint = "Search tools…"; setHintTextColor(NukeHudPalette.MutedDeep); setTextColor(NukeHudPalette.Text); textSize = 9f
            isSingleLine = true; background = getDrawable(R.drawable.nuke_hud_search); setPadding(dp(12), 0, dp(12), 0); minHeight = dp(40)
        }
        actions.addView(search, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply { bottomMargin = dp(6) })
        val categories = listOf("ALL", "PERFORMANCE", "NETWORK", "DISPLAY", "MONITOR", "SESSION", "FOCUS")
        var selectedCategory = "ALL"
        var render: (() -> Unit)? = null
        val selector = spinner(categories, 0) { index -> selectedCategory = categories[index]; render?.invoke() }
        actions.addView(selector, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply { bottomMargin = dp(6) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        actions.addView(list)

        fun cap(id: String): Boolean? = engine?.state?.value?.capabilities?.firstOrNull { it.id == id }?.supported
        val specs = listOf(
            FeatureSpec("Aim Response", "DPI + response profile", "PERFORMANCE", R.drawable.nuke_ic_aim_response) { openAimResponse() },
            FeatureSpec("FPS Max", "Native refresh + measured FPS", "PERFORMANCE", R.drawable.nuke_ic_speed) { openMaxFps() },
            FeatureSpec("Deep Clean", "Measured memory/cache cleanup", "PERFORMANCE", R.drawable.nuke_ic_clean) { openDeepClean() },
            FeatureSpec("CPU Core Clocks", "Read-only per-core MHz", "MONITOR", R.drawable.nuke_ic_monitor, "cpu_clocks", { engine?.state?.value?.adbConnected == true }) { openCpuClocks() },
            FeatureSpec("Live Telemetry", "CPU • RAM • display", "MONITOR", R.drawable.nuke_ic_monitor) { openMonitor() },
            FeatureSpec("Pressure Radar", "Measured process pressure", "MONITOR", R.drawable.nuke_ic_radar) { openResourceRadar() },
            FeatureSpec("Wi-Fi Link Quality", "RSSI • link speed • ping", "NETWORK", R.drawable.nuke_ic_network, "wifi_link") { openNetwork() },
            FeatureSpec("Graphics Engine", "Safe session resolution + density profiles", "DISPLAY", R.drawable.nuke_ic_display, "display_profiles", { engine?.state?.value?.adbConnected == true }) { openGraphicsEngine() },
            FeatureSpec("Screen Control", "Display/session controls", "DISPLAY", R.drawable.nuke_ic_screen_control) { openScreenControl() },
            FeatureSpec("Crosshair Studio", "Visual aim overlay", "DISPLAY", R.drawable.nuke_ic_crosshair) { openCrosshairStudio() },
            FeatureSpec("Session Battery", "Percent + charge delta", "SESSION", R.drawable.nuke_ic_battery_saver, "session_battery") { openSessionBattery() },
            FeatureSpec("Background Sweep", "Manual protected cached-app release", "FOCUS", R.drawable.nuke_ic_background_sweep, "background_sweep", { engine?.state?.value?.adbConnected == true }) { runEngineAction { sweepSafeBackground() } },
        )
        render = {
            val q = search.text?.toString()?.trim()?.lowercase(Locale.US).orEmpty()
            list.removeAllViews()
            var visible = 0
            specs.filter { spec ->
                (selectedCategory == "ALL" || spec.category == selectedCategory) &&
                    (q.isBlank() || spec.title.lowercase(Locale.US).contains(q) || spec.subtitle.lowercase(Locale.US).contains(q))
            }.forEach { spec ->
                val supported = spec.capability?.let { cap(it) } ?: spec.fallbackSupported()
                val tile = NukeActionTileView(this).apply {
                    configure(spec.title, "${spec.category} • ${spec.subtitle}", spec.icon, false)
                    alpha = if (supported) 1f else .48f
                    setOnClickListener {
                        if (!supported) toastOutcome("${spec.title} unsupported on this device or current connection")
                        else { removeWindow(key); spec.action() }
                    }
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(5) }
                }
                list.addView(tile); visible++
            }
            status.text = "PLAY-ORIENTED CATALOG • $visible SHOWN • ${specs.count { spec -> spec.capability?.let { cap(it) } ?: spec.fallbackSupported() }} AVAILABLE"
            if (visible == 0) list.addView(noteText("No tools match this filter."))
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render?.invoke() }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        render?.invoke()
        bindModuleWindow(key, view, x = dp(12), y = dp(48))
    }

    private fun openGraphicsEngine() {
        val key = "graphics_engine"
        if (windows.containsKey(key)) { removeWindow(key); return }
        val view = moduleView("GRAPHICS ENGINE", "SESSION DISPLAY • SAFE PROFILES • AUTO RESTORE")
        val status = view.findViewById<TextView>(R.id.moduleStatus)
        val actions = view.findViewById<LinearLayout>(R.id.moduleActions)
        actions.addView(noteText("Changes the whole device rendering size/density only for a user-started game session. Game Nuke never upscales above the current display, never edits game files, and restores only values it still owns."))

        val profiles = NukeDisplayProfileController.profiles()
        var selected = NukeDisplayProfileController.stagedProfile(this)
        actions.addView(controlTitle("DISPLAY PROFILE"))
        val selector = spinner(
            profiles.map { "${it.title}  •  ${it.scalePercent}%" },
            profiles.indexOf(selected).takeIf { it >= 0 } ?: 0,
        ) { index ->
            selected = profiles[index.coerceIn(0, profiles.lastIndex)]
        }
        actions.addView(selector, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).apply { bottomMargin = dp(6) })

        val preview = TextView(this).apply {
            setTextColor(NukeHudPalette.Muted); textSize = 8.5f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = getDrawable(R.drawable.nuke_hud_detail)
            text = "Preview is read-only and requires Extended Device Control."
        }
        actions.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })

        fun refreshPreview(profile: NukeDisplayProfileController.Profile = selected) {
            status.text = "READING DISPLAY SAFETY LIMITS…"
            scope.launch {
                val result = withContext(Dispatchers.IO) { NukeDisplayProfileController.preview(applicationContext, profile) }
                if (!windows.containsKey(key)) return@launch
                val p = result.preview
                when {
                    p != null -> {
                        preview.text = "BASE     ${p.sourceWidth}×${p.sourceHeight} @ ${p.sourceDensity}dpi\nTARGET   ${p.targetWidth}×${p.targetHeight} @ ${p.targetDensity}dpi\nSAFE SCALE  ${p.effectiveScalePercent}%  •  ${p.profile.detail}"
                        status.text = "READY • ${p.profile.title} • APPLIES NEXT GAME LAUNCH"
                    }
                    result.result.outcome == NukeDisplayProfileController.Outcome.UNSUPPORTED -> {
                        preview.text = result.result.message
                        status.text = "UNSUPPORTED • DISPLAY OVERRIDE UNAVAILABLE"
                    }
                    else -> {
                        preview.text = result.result.message
                        status.text = "ERROR • DISPLAY PREVIEW FAILED"
                    }
                }
            }
        }

        selector.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, child: View?, position: Int, id: Long) {
                selected = profiles[position.coerceIn(0, profiles.lastIndex)]
                refreshPreview(selected)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        actions.addView(actionButton("ARM PROFILE FOR NEXT GAME") {
            if (!acceptAction()) return@actionButton
            val result = NukeDisplayProfileController.stageProfile(applicationContext, selected)
            when (result.outcome) {
                NukeDisplayProfileController.Outcome.SUCCESS, NukeDisplayProfileController.Outcome.UNCHANGED -> NukeToast.success(applicationContext, result.message)
                NukeDisplayProfileController.Outcome.UNSUPPORTED -> NukeToast.unsupported(applicationContext, result.message, true)
                else -> NukeToast.error(applicationContext, result.message, true)
            }
            refreshPreview(selected)
        })
        actions.addView(actionButton("RESTORE DISPLAY NOW") {
            if (!acceptAction()) return@actionButton
            if (!NukeDisplayProfileController.hasOwnedOverride(applicationContext)) {
                NukeToast.success(applicationContext, "Display is already outside Game Nuke ownership")
                return@actionButton
            }
            val reopenHub = windows.containsKey("hub")
            removeAllWindowsImmediate()
            scope.launch {
                val result = withContext(Dispatchers.IO) { NukeDisplayProfileController.restoreIfOwned(applicationContext) }
                delay(180L)
                ensureEdge()
                syncCrosshairOverlay()
                if (reopenHub) openHub()
                when (result.outcome) {
                    NukeDisplayProfileController.Outcome.SUCCESS, NukeDisplayProfileController.Outcome.UNCHANGED -> NukeToast.success(applicationContext, result.message, true)
                    NukeDisplayProfileController.Outcome.UNSUPPORTED -> NukeToast.unsupported(applicationContext, result.message, true)
                    else -> NukeToast.error(applicationContext, result.message, true)
                }
            }
        })
        actions.addView(noteText("Profiles are intentionally bounded: 100/90/82/75%. If the device is already low resolution, Game Nuke automatically raises the floor instead of forcing an unsafe size. Density follows the same scale to keep UI geometry stable. No Force-4x-MSAA or HW-overlay mutation is shipped until exact property behavior is verified per OEM/API."))
        bindModuleWindow(key, view, x = dp(12), y = dp(48))
        refreshPreview(selected)
    }

    private fun openCpuClocks() {
        val key = "cpu_clocks"
        if (windows.containsKey(key)) { removeWindow(key); return }
        val local = NukeGamingShellGateway(AdbManager.getInstance(applicationContext))
        if (!local.connected()) { toastOutcome("CPU Core Clocks unsupported until Extended Control is connected"); return }
        val view = moduleView("CPU CORE CLOCKS", "READ-ONLY • PER-CORE • LIVE")
        val metrics = view.findViewById<LinearLayout>(R.id.moduleMetrics)
        val status = view.findViewById<TextView>(R.id.moduleStatus)
        view.findViewById<LinearLayout>(R.id.moduleActions).addView(noteText("Reads scaling_cur_freq only. Game Nuke never writes CPU frequency or governor sysfs nodes."))
        bindModuleWindow(key, view, x = dp(18), y = dp(68))
        scope.launch {
            while (isActive && windows.containsKey(key)) {
                val clocks = withContext(Dispatchers.IO) { local.readCpuClocks() }
                metrics.removeAllViews()
                if (clocks.isEmpty()) {
                    status.text = "UNSUPPORTED • CPU CLOCK SYSFS NOT READABLE"
                    metrics.addView(noteText("This kernel/OEM does not expose scaling_cur_freq to the shell identity."))
                } else {
                    status.text = "LIVE • ${clocks.size} CORES"
                    clocks.forEach { row -> metrics.addView(metricLine("CPU${row.core}", "${row.mhz} MHz")) }
                }
                delay(2_500L)
            }
        }
    }

    private fun captureSessionBatteryBaseline() {
        sessionStartedElapsed = SystemClock.elapsedRealtime()
        val snapshot = readBatterySnapshot()
        sessionBatteryStartPercent = snapshot.first
        sessionChargeStartUah = snapshot.second
    }

    private fun readBatterySnapshot(): Pair<Int, Int?> {
        val percent = runCatching {
            val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            if (level >= 0 && scale > 0) ((level * 100f) / scale).roundToInt().coerceIn(0, 100) else -1
        }.getOrDefault(-1)
        val charge = runCatching {
            val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).takeUnless { it == Int.MIN_VALUE }
        }.getOrNull()
        return percent to charge
    }

    private fun sessionBatterySummary(): String {
        val now = readBatterySnapshot()
        val pctDrop = if (sessionBatteryStartPercent >= 0 && now.first >= 0) (sessionBatteryStartPercent - now.first).coerceAtLeast(0) else null
        val startCharge = sessionChargeStartUah
        val endCharge = now.second
        val mah = if (startCharge != null && endCharge != null) ((startCharge - endCharge) / 1000f).coerceAtLeast(0f) else null
        val mins = if (sessionStartedElapsed > 0L) ((SystemClock.elapsedRealtime() - sessionStartedElapsed) / 60_000L).coerceAtLeast(0) else 0
        return buildList {
            add("${mins}m")
            pctDrop?.let { add("$it% used") }
            mah?.takeIf { it > .05f }?.let { add(String.format(Locale.US, "%.0fmAh", it)) }
        }.joinToString(" • ")
    }

    private fun openSessionBattery() {
        val key = "session_battery"
        if (windows.containsKey(key)) { removeWindow(key); return }
        val view = moduleView("SESSION BATTERY", "LOCAL BASELINE • NO BATTERYSTATS RESET")
        val metrics = view.findViewById<LinearLayout>(R.id.moduleMetrics)
        val value = metricLine("SESSION", sessionBatterySummary())
        metrics.addView(value)
        val actions = view.findViewById<LinearLayout>(R.id.moduleActions)
        actions.addView(noteText("Uses local battery percent and, when the device exposes it, BatteryManager charge_counter. It never resets global Android batterystats."))
        actions.addView(actionButton("REFRESH SESSION BATTERY") { value.text = "SESSION  ${sessionBatterySummary()}"; toastOutcome("Session battery summary refreshed") })
        bindModuleWindow(key, view, x = dp(22), y = dp(72))
    }

    private fun openMonitor() {
        val key = "monitor"
        if (windows.containsKey(key)) {
            if (monitorTouchThrough) { monitorTouchThrough = false; applyMonitorTouchMode() } else removeWindow(key)
            return
        }
        val view = moduleView("LIVE TELEMETRY", "REAL DATA // LOW OVERHEAD")
        val metrics = view.findViewById<LinearLayout>(R.id.moduleMetrics)
        val cpuLabel = metricLine("CPU LOAD", "--")
        val ramLabel = metricLine("RAM USED", "--")
        val displayLabel = metricLine("DISPLAY", "--")
        val cpuSpark = NukeSparklineView(this).apply { minimumHeight = dp(58) }
        val ramSpark = NukeSparklineView(this).apply { minimumHeight = dp(58) }
        metrics.addView(cpuLabel); metrics.addView(cpuSpark, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(58)))
        metrics.addView(ramLabel); metrics.addView(ramSpark, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(58)))
        metrics.addView(displayLabel)
        view.setTag(R.id.monitorCpuTag, cpuLabel); view.setTag(R.id.monitorRamTag, ramLabel); view.setTag(R.id.monitorDisplayTag, displayLabel)
        view.setTag(R.id.monitorCpuSparkTag, cpuSpark); view.setTag(R.id.monitorRamSparkTag, ramSpark)
        val actions = view.findViewById<LinearLayout>(R.id.moduleActions)
        actions.addView(actionButton("ENABLE TOUCH-THROUGH") {
            if (!acceptAction()) return@actionButton
            monitorTouchThrough = !monitorTouchThrough
            applyMonitorTouchMode()
            toastOutcome("Telemetry touch-through ${if (monitorTouchThrough) "enabled" else "disabled"}")
        })
        actions.addView(actionButton("RESAMPLE REAL FPS") {
            if (!acceptAction()) return@actionButton
            scope.launch {
                val local = engine
                if (local == null) toastOutcome("FPS sampler is not ready")
                else {
                    runCatching { local.sampleActualGameFps() }
                    toastOutcome(local.state.value.message)
                }
            }
        })
        bindModuleWindow(key, view, x = dp(18), y = dp(102))
        applyMonitorTouchMode()
        engine?.state?.value?.let(::updateTelemetryUi)
    }

    private fun openModule(key: String, title: String, subtitle: String, entries: List<HudAction>) {
        if (windows.containsKey(key)) { removeWindow(key); return }
        val view = moduleView(title, subtitle)
        val actions = view.findViewById<LinearLayout>(R.id.moduleActions)
        entries.forEach { entry ->
            val button = actionButton(entry.label, entry.danger) {
                if (!entry.enabled()) {
                    view.findViewById<TextView>(R.id.moduleStatus).text = "ACTION UNAVAILABLE ON THIS DEVICE/STATE"
                    toastOutcome("${entry.label} unavailable on this device or state")
                    return@actionButton
                }
                if (!acceptAction()) return@actionButton
                scope.launch {
                    val before = engine?.state?.value?.message
                    val result = runCatching { entry.action() }.onFailure { Log.w(TAG, "Action ${entry.label} failed", it) }
                    engine?.state?.value?.let { updateTelemetryUi(it); publishRuntime(it) }
                    val after = engine?.state?.value?.message
                    when {
                        result.isFailure -> toastOutcome("${entry.label} failed: ${result.exceptionOrNull()?.message ?: "unknown error"}")
                        after != null && after != before -> toastOutcome(after)
                        else -> toastOutcome("${entry.label} completed")
                    }
                }
            }
            button.isEnabled = entry.enabled()
            button.alpha = if (button.isEnabled) 1f else .48f
            actions.addView(button)
        }
        bindModuleWindow(key, view)
    }

    private fun moduleView(title: String, subtitle: String): View =
        LayoutInflater.from(this).inflate(R.layout.nuke_hud_module, null).also { view ->
            view.findViewById<TextView>(R.id.moduleTitle).text = title
            view.findViewById<TextView>(R.id.moduleSubtitle).text = subtitle
        }

    private fun bindModuleWindow(key: String, view: View, x: Int? = null, y: Int? = null) {
        view.findViewById<View>(R.id.moduleClose).safeClick { removeWindow(key); setHubActive(null) }
        val width = scaledModuleWidth()
        val p = params(width, moduleHeight()).apply {
            this.x = x ?: (dp(14) + (windows.size % 3) * dp(26)).coerceAtMost(dp(92))
            this.y = y ?: dp(76) + (windows.size % 4) * dp(22)
        }
        addWindow(key, view, p)
        makeDraggable(key, view.findViewById(R.id.moduleDrag))
        engine?.state?.value?.let(::updateTelemetryUi)
    }

    private fun syncCrosshairOverlay() {
        val enabled = prefs.safeBoolean("cross_en", false)
        if (!enabled) {
            removeWindow("crosshair")
            publishRuntime(engine?.state?.value)
            return
        }
        val view = (windows["crosshair"]?.view as? NukeCrosshairView) ?: NukeCrosshairView(this).also { cross ->
            val p = params(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT).apply {
                x = 0; y = 0
                flags = baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                alpha = 1f
            }
            addWindow("crosshair", cross, p)
        }
        val styles = NukeCrosshairView.Style.values()
        view.style = styles[prefs.safeInt("cross_type", 1).coerceIn(0, styles.lastIndex)]
        view.crosshairColor = prefs.safeInt("cross_color", NukeHudPalette.Green)
        view.sizeDp = prefs.safeInt("cross_size", 22).toFloat()
        view.gapDp = prefs.safeInt("cross_gap", 6).toFloat()
        view.thicknessDp = prefs.safeInt("cross_thickness", 2).toFloat()
        view.opacity = prefs.safeInt("cross_opacity", 95).coerceIn(20, 100) / 100f
        view.offsetXPx = prefs.safeInt("cross_x", 0).toFloat()
        view.offsetYPx = prefs.safeInt("cross_y", 0).toFloat()
        view.centerDot = prefs.safeBoolean("cross_dot", true)
        view.outline = prefs.safeBoolean("cross_outline", true)
        view.enabledCrosshair = true
        publishRuntime(engine?.state?.value)
    }

    private fun setHudScale(scale: Float) {
        val safe = scale.coerceIn(.85f, 1.15f)
        prefs.edit().putFloat(K_HUD_SCALE, safe).apply()
        windows.forEach { (key, slot) ->
            if (key in setOf("edge", "banner", "crosshair")) return@forEach
            when (key) {
                "hub" -> { slot.params.width = scaledHubWidth(); slot.params.height = scaledHubHeight(); slot.params.x = centeredX(slot.params.width); slot.params.y = (screenHeight() - slot.params.height - dp(10)).coerceAtLeast(0) }
                else -> { slot.params.width = scaledModuleWidth(); slot.params.height = moduleHeight() }
            }
            slot.params.x = slot.params.x.coerceIn(0, maxOf(0, screenWidth() - slot.params.width))
            slot.params.y = slot.params.y.coerceIn(0, maxOf(0, screenHeight() - slot.params.height))
            runCatching { wm.updateViewLayout(slot.view, slot.params) }
        }
    }

    private fun setHudAlpha(alpha: Float) {
        prefs.edit().putFloat(K_HUD_ALPHA, alpha.coerceIn(.72f, .98f)).apply()
        applyHudAlphaToOpenWindows()
    }

    private fun applyHudAlphaToOpenWindows() {
        val safe = prefs.safeFloat(K_HUD_ALPHA, .96f).coerceIn(.72f, .98f)
        windows.forEach { (key, slot) ->
            if (key == "crosshair") return@forEach
            slot.params.alpha = if (key == "monitor" && monitorTouchThrough) minOf(.78f, safe) else safe
            runCatching { wm.updateViewLayout(slot.view, slot.params) }
        }
    }

    private fun applyMonitorTouchMode() {
        val slot = windows["monitor"] ?: return
        slot.params.flags = if (monitorTouchThrough) baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else baseFlags()
        slot.params.alpha = if (monitorTouchThrough) .78f else prefs.safeFloat(K_HUD_ALPHA, .96f).coerceIn(.72f, .98f)
        runCatching { wm.updateViewLayout(slot.view, slot.params) }
    }

    private suspend fun refreshAuxTelemetry(retryPing: Boolean = false) {
        pingMeasuring = true
        withContext(Dispatchers.IO) {
        batteryPercent = runCatching {
            val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val tempRaw = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            batteryTempC = if (tempRaw > 0) tempRaw / 10f else null
            if (level >= 0 && scale > 0) ((level * 100f) / scale).roundToInt().coerceIn(0, 100) else -1
        }.getOrDefault(-1)

        networkLabel = runCatching {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            wifiRssiDbm = null; wifiLinkMbps = null
            when {
                caps == null -> "OFFLINE"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                    val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                    @Suppress("DEPRECATION") val info = wifi?.connectionInfo
                    val rssi = info?.rssi?.takeIf { it in -126..-1 }
                    val link = info?.linkSpeed?.takeIf { it > 0 }
                    wifiRssiDbm = rssi; wifiLinkMbps = link
                    if (rssi != null) "WIFI ${rssi}dBm" else "WIFI"
                }
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MOBILE"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETH"
                else -> "ONLINE"
            }
        }.getOrDefault("--")

            var measured = measurePingOnce(600)
            if (measured == null && retryPing) {
                delay(180L)
                measured = measurePingOnce(500)
            }
            lastPingMs = measured
        }
        pingMeasuring = false
    }

    private suspend fun measurePingOnce(connectTimeoutMs: Int): Long? = withTimeoutOrNull(connectTimeoutMs.toLong() + 150L) {
        withContext(Dispatchers.IO) {
            runCatching {
                val started = System.nanoTime()
                Socket().use { socket -> socket.connect(InetSocketAddress("1.1.1.1", 443), connectTimeoutMs) }
                (((System.nanoTime() - started) / 1_000_000L).coerceAtLeast(1L)).coerceAtMost(999L)
            }.getOrNull()
        }
    }

    private fun applyKeepAwake() {
        val enabled = prefs.safeBoolean("hud_keep_awake", false)
        listOf("edge", "hub").forEach { key ->
            val slot = windows[key] ?: return@forEach
            val desired = if (enabled) {
                slot.params.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            } else {
                slot.params.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
            }
            if (slot.params.flags != desired) {
                slot.params.flags = desired
                runCatching { wm.updateViewLayout(slot.view, slot.params) }
                    .onFailure { Log.w(TAG, "KEEP_SCREEN_ON update failed for $key", it) }
            }
        }
    }

    private fun updateTelemetryUi(state: NukePerformanceEngine.State) {
        val ramKnown = state.ramTotalMb > 0L
        val usedRamPercent = if (ramKnown) {
            (((state.ramTotalMb - state.ramAvailableMb).toDouble() / state.ramTotalMb) * 100.0)
                .roundToInt().coerceIn(0, 100)
        } else 0
        val cpu = state.cpuLoadPercent ?: 0
        val storageUsedPercent = if (state.storageTotalGb > 0f) {
            (((state.storageTotalGb - state.storageFreeGb) / state.storageTotalGb) * 100f)
                .roundToInt().coerceIn(0, 100)
        } else 0

        val reactorStatus = when {
            state.adbConnected && state.currentHz > 0 -> NukeReactorCoreView.Status.ONLINE
            state.adbConnected || state.currentHz > 0 -> NukeReactorCoreView.Status.DEGRADED
            else -> NukeReactorCoreView.Status.OFFLINE
        }

        // The minimized rail intentionally exposes no raw HZ/LINK/CPU/RAM text. The N reactor
        // communicates health through color + pulse only, keeping the game viewport clean.
        windows["edge"]?.view?.findViewById<NukeReactorCoreView>(R.id.edgeReactor)?.setStatus(reactorStatus)

        windows["hub"]?.view?.let { v ->
            v.findViewById<NukeReactorCoreView>(R.id.hubReactor)?.setStatus(reactorStatus)
            v.findViewById<NukeSpeedometerView>(R.id.gaugeCpu)?.let { gauge -> if (state.cpuLoadPercent != null) gauge.setValue(cpu) else gauge.setUnavailable() }
            v.findViewById<NukeSpeedometerView>(R.id.gaugeRam)?.let { gauge -> if (ramKnown) gauge.setValue(usedRamPercent) else gauge.setUnavailable() }
            v.findViewById<TextView>(R.id.hubCpuValue)?.text = state.cpuLoadPercent?.let { "$it%" } ?: "--%"
            v.findViewById<TextView>(R.id.hubRamValue)?.text = if (ramKnown) "$usedRamPercent%" else "--%"
            v.findViewById<TextView>(R.id.hubRamSub)?.text = if (ramKnown) {
                val usedGb = (state.ramTotalMb - state.ramAvailableMb).coerceAtLeast(0L) / 1024f
                val totalGb = state.ramTotalMb / 1024f
                "${String.format(Locale.US, "%.1f", usedGb)} GB / ${String.format(Locale.US, "%.1f", totalGb)} GB"
            } else "-- / --"
            v.findViewById<TextView>(R.id.hubGame)?.text = "GAME NUKE  //  ${state.gameLabel.uppercase(Locale.US)}"
            v.findViewById<TextView>(R.id.hubPhase)?.text = when (state.phase) {
                NukePerformanceEngine.Phase.ACTIVE -> "PRIORITY OPTIMIZATION ACTIVE"
                NukePerformanceEngine.Phase.DEGRADED -> "COMPATIBILITY MODE"
                NukePerformanceEngine.Phase.PROBING, NukePerformanceEngine.Phase.APPLYING,
                NukePerformanceEngine.Phase.RESTORING -> "OPTIMIZATION IN PROGRESS"
                NukePerformanceEngine.Phase.ERROR -> "CORE NEEDS ATTENTION"
                else -> "CORE READY"
            }
            v.findViewById<TextView>(R.id.hubFps)?.text = "FPS ${state.lastMeasuredFps?.let { String.format(Locale.US, "%.0f", it) } ?: "--"}"
            v.findViewById<TextView>(R.id.hubPing)?.text = "PING ${lastPingMs?.let { "${it}ms" } ?: if (pingMeasuring) "MEASURING…" else "--"}"
            v.findViewById<TextView>(R.id.hubThermal)?.text = "TEMP ${batteryTempC?.let { String.format(Locale.US, "%.1f°C", it) } ?: thermalLabel(state.thermalStatus)}"
            v.findViewById<TextView>(R.id.hubBattery)?.text = "BAT ${if (batteryPercent >= 0) "$batteryPercent%" else "--"}"
            v.findViewById<TextView>(R.id.hubStorage)?.text = "STO ${if (state.storageTotalGb > 0f) "$storageUsedPercent%" else "--"}"
            v.findViewById<TextView>(R.id.hubNetworkState)?.text = "NET $networkLabel"
            v.findViewById<TextView>(R.id.hubStatus)?.text = userFacingStatus(state.message).take(132)

            if ((state.message.contains("THERMAL GUARD", true) ||
                    state.message.contains("THERMAL RECOVERED", true) ||
                    state.message.contains("AUTO MEMORY COMPACT", true)) &&
                state.message != lastAutomaticAlert
            ) {
                lastAutomaticAlert = state.message
                toastStatus("AUTO • ${state.message}")
            }

            fun tool(id: Int): NukeHudToolView? = v.findViewById(id)
            fun toggle(id: Int): NukeHudToggleView? = v.findViewById(id)
            fun capability(id: String): Boolean? = state.capabilities.firstOrNull { it.id == id }?.supported
            toggle(R.id.hubGameMode)?.apply {
                setSupported(true)
                setCheckedSilently(prefs.safeBoolean(K_ADAPTIVE_GAME_MODE, false))
            }
            toggle(R.id.hubDnd)?.apply { setSupported(true); setCheckedSilently(state.dndActive) }
            toggle(R.id.hubCallShield)?.apply {
                setSupported(NukeCallShield.isSupported(this@FloatingBoosterService))
                setCheckedSilently(NukeCallShield.isEnabled(this@FloatingBoosterService))
            }
            // Battery/Data switches stay usable even without the extended control path because the
            // engine opens the matching Android Settings screen as a safe fallback.
            toggle(R.id.hubBatterySaver)?.apply { setSupported(true); setCheckedSilently(state.batterySaverActive == true) }
            toggle(R.id.hubDataSaver)?.apply { setSupported(true); setCheckedSilently(state.dataSaverActive == true) }
            toggle(R.id.hubNetworkBoost)?.apply {
                setSupported(packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_WIFI))
                setCheckedSilently(state.networkBoostActive)
            }
            tool(R.id.hubBackgroundSweep)?.setSupported(capability("background_sweep") ?: state.adbConnected)
            tool(R.id.hubMaxFps)?.setSupported(true)
            tool(R.id.hubNetwork)?.setSupported(true)
            tool(R.id.hubMonitor)?.setSupported(true)
            tool(R.id.hubCrosshair)?.setSupported(true)
            tool(R.id.hubDeepClean)?.setSupported(true)
            tool(R.id.hubAimResponse)?.setSupported(true)
            tool(R.id.hubRadar)?.setSupported(true)
            tool(R.id.hubScreenControl)?.setSupported(true)
        }

        listOf("max_fps", "network", "monitor").forEach { key ->
            windows[key]?.view?.findViewById<TextView>(R.id.moduleStatus)?.text = userFacingStatus(state.message).take(180)
        }
        windows["monitor"]?.view?.let { v ->
            (v.getTag(R.id.monitorCpuTag) as? TextView)?.text = "CPU LOAD  ${state.cpuLoadPercent?.let { "$it%" } ?: "N/A"}"
            (v.getTag(R.id.monitorRamTag) as? TextView)?.text = if (ramKnown) "RAM USED  $usedRamPercent%  // FREE ${state.ramAvailableMb}MB" else "RAM USED  N/A"
            (v.getTag(R.id.monitorDisplayTag) as? TextView)?.text = "DISPLAY  ${state.currentHz.takeIf { it > 0 } ?: "--"}Hz / ${state.maxHz.takeIf { it > 0 } ?: "--"}Hz  // ${if (state.adbConnected) "EXTENDED" else "STANDARD"}"
            if (state.cpuLoadPercent != null) (v.getTag(R.id.monitorCpuSparkTag) as? NukeSparklineView)?.push(cpu)
            if (ramKnown) (v.getTag(R.id.monitorRamSparkTag) as? NukeSparklineView)?.push(usedRamPercent)
        }
    }

    private fun publishRuntime(state: NukePerformanceEngine.State?) {
        NukeRuntimeState.publish(
            NukeRuntimeState.Snapshot(
                overlayRunning = prefs.safeBoolean(K_ACTIVE, false) && foregroundStarted,
                activePackage = targetPackage ?: prefs.safeString(K_ACTIVE_PACKAGE, "").takeIf { it.isNotBlank() },
                language = validLanguage(prefs.safeString(K_LANG, "en")),
                crosshairEnabled = windows.containsKey("crosshair") && prefs.safeBoolean("cross_en", false),
                currentHz = state?.currentHz ?: 0,
                maxHz = state?.maxHz ?: 0,
                lastFps = state?.lastMeasuredFps,
                phase = state?.phase?.name ?: "IDLE",
                message = state?.message ?: "CORE STANDBY",
            ),
        )
    }

    private fun refreshLocalizedHud() {
        windows["hub"]?.view?.let { hub ->
            hub.findViewById<TextView>(R.id.hubMode)?.text = Tx.t("INTI NUKE", "NUKE CORE")
            hub.findViewById<TextView>(R.id.hubAllTools)?.text = Tx.t("SEMUA ›", "ALL TOOLS ›")
            configureHubTools(hub)
        }
    }

    private fun userFacingStatus(raw: String): String = raw
        .replace("WIRELESS ADB", "DEVICE LINK", ignoreCase = true)
        .replace("ADB", "EXTENDED CONTROL", ignoreCase = true)
        .replace("SHELL", "DEVICE", ignoreCase = true)
        .replace("LOCAL CORE", "CONNECTION", ignoreCase = true)
        .replace("DEVICE_CONFIG", "DEVICE PROFILE", ignoreCase = true)
        .replace("ART PRIME", "GAME PREP", ignoreCase = true)

    private fun thermalLabel(status: Int): String = when {
        status >= PowerManager.THERMAL_STATUS_SEVERE -> "HOT"
        status >= PowerManager.THERMAL_STATUS_MODERATE -> "WARM"
        status >= PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
        else -> "OK"
    }

    private fun metricLine(label: String, value: String): TextView = TextView(this).apply {
        text = "$label  $value"
        setTextColor(NukeHudPalette.Text); textSize = 9f
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        setPadding(dp(4), dp(5), dp(4), dp(5))
    }

    private fun controlTitle(textValue: String): TextView = TextView(this).apply {
        text = textValue
        setTextColor(NukeHudPalette.Cyan); textSize = 8f
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        setPadding(dp(4), dp(9), dp(4), dp(3))
    }

    private fun noteText(value: String): TextView = TextView(this).apply {
        text = value
        setTextColor(NukeHudPalette.Muted); textSize = 8.5f
        setPadding(dp(5), dp(6), dp(5), dp(8))
    }

    private fun actionButton(label: String, danger: Boolean = false, click: () -> Unit): NukeActionTileView = NukeActionTileView(this).apply {
        val icon = when {
            label.contains("FPS", true) || label.contains("FRAME", true) -> R.drawable.nuke_ic_speed
            label.contains("NETWORK", true) || label.contains("ADB", true) || label.contains("LATENCY", true) -> R.drawable.nuke_ic_network
            label.contains("CLEAN", true) || label.contains("CACHE", true) || label.contains("RECLAIM", true) -> R.drawable.nuke_ic_clean
            label.contains("DISPLAY", true) || label.contains("DPI", true) -> R.drawable.nuke_ic_display
            label.contains("FOCUS", true) -> R.drawable.nuke_ic_focus
            else -> R.drawable.nuke_ic_session
        }
        configure(label, if (danger) "RESTORE / DESTRUCTIVE CONTROL" else "VERIFIED GAME NUKE CONTROL", icon, danger)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50)).apply { topMargin = dp(5) }
    }

    private fun styleCheck(box: CheckBox) {
        box.setTextColor(NukeHudPalette.Text); box.textSize = 9f
        box.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        box.buttonTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(NukeHudPalette.Green, NukeHudPalette.MutedDeep),
        )
        box.setPadding(dp(4), dp(2), dp(4), dp(2)); box.minHeight = dp(36)
    }

    private fun styleSwitch(switch: Switch) {
        switch.setTextColor(NukeHudPalette.Text); switch.textSize = 9f
        switch.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        switch.thumbTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(Color.WHITE, Color.rgb(190, 198, 193)),
        )
        switch.trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(NukeHudPalette.GreenDim, NukeHudPalette.PanelSoft),
        )
        switch.setPadding(dp(4), dp(3), dp(4), dp(3)); switch.minHeight = dp(40)
    }

    private fun spinner(items: List<String>, initial: Int, onSelected: (Int) -> Unit): Spinner = Spinner(this).apply {
        val adapter = object : ArrayAdapter<String>(this@FloatingBoosterService, android.R.layout.simple_spinner_item, items) {
            init { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                return (super.getView(position, convertView, parent) as TextView).apply {
                    setTextColor(NukeHudPalette.Text); textSize = 8.5f
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    setPadding(dp(10), 0, dp(10), 0)
                }
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                return (super.getDropDownView(position, convertView, parent) as TextView).apply {
                    setTextColor(NukeHudPalette.Text); setBackgroundColor(NukeHudPalette.Panel); textSize = 9f
                    typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                }
            }
        }
        this.adapter = adapter
        setSelection(initial.coerceIn(0, maxOf(0, items.lastIndex)), false)
        background = getDrawable(R.drawable.nuke_hud_search)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { onSelected(position) }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        minimumHeight = dp(40); setPadding(dp(8), 0, dp(8), 0)
    }

    private fun seekControl(label: String, min: Int, max: Int, initial: Int, onChanged: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(3), dp(4), dp(3), dp(4)) }
        val valueLabel = TextView(this).apply {
            setTextColor(NukeHudPalette.Text); textSize = 8.5f; typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = initial.coerceIn(min, max) - min
            progressTintList = ColorStateList.valueOf(NukeHudPalette.Green)
            thumbTintList = ColorStateList.valueOf(NukeHudPalette.Text)
            progressBackgroundTintList = ColorStateList.valueOf(NukeHudPalette.MutedDeep)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + min
                    valueLabel.text = "$label  $value"
                    if (fromUser) onChanged(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        valueLabel.text = "$label  ${initial.coerceIn(min, max)}"
        row.addView(valueLabel); row.addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(38)))
        return row
    }

    private fun addWindow(key: String, view: View, p: WindowManager.LayoutParams) {
        if (windows.containsKey(key)) return
        p.alpha = if (key == "crosshair") 1f else prefs.safeFloat(K_HUD_ALPHA, .96f).coerceIn(.72f, .98f)
        if (key != "crosshair") {
            view.alpha = 0f
            view.scaleX = .965f
            view.scaleY = .965f
            view.translationY = dp(5).toFloat()
        }
        val ok = runCatching { wm.addView(view, p) }.onFailure { Log.e(TAG, "addWindow $key failed", it) }.isSuccess
        if (ok) {
            windows[key] = WindowSlot(view, p)
            if (key != "crosshair") NukeMotionEngine.reveal(view, fromScale = if (key == "hub") .94f else .91f, fromY = dp(if (key == "hub") 10 else 16).toFloat())
        }
    }

    private fun removeWindow(key: String) {
        val slot = windows.remove(key) ?: return
        NukeMotionEngine.cancel(slot.view)
        if (key == "crosshair" || !slot.view.isAttachedToWindow) { runCatching { wm.removeViewImmediate(slot.view) }; return }
        slot.view.animate().cancel()
        slot.view.animate().alpha(0f).scaleX(.96f).scaleY(.96f).translationY(dp(5).toFloat()).setDuration(95L)
            .withEndAction { runCatching { if (slot.view.isAttachedToWindow) wm.removeViewImmediate(slot.view) } }.start()
    }

    private fun removeAllWindows() { windows.keys.toList().forEach(::removeWindow) }

    private fun removeAllWindowsImmediate() {
        windows.keys.toList().forEach { key ->
            val slot = windows.remove(key) ?: return@forEach
            runCatching { NukeMotionEngine.cancel(slot.view) }
            runCatching { slot.view.animate().cancel() }
            runCatching { if (slot.view.isAttachedToWindow) wm.removeViewImmediate(slot.view) }
                .onFailure { Log.w(TAG, "Immediate overlay removal failed for $key", it) }
        }
    }

    private fun closeModulesKeepEdge() {
        windows.keys.filter { it !in setOf("edge", "crosshair") }.forEach(::removeWindow)
    }

    private fun makeDraggable(
        key: String,
        handle: View,
        tap: (() -> Unit)? = null,
        longPress: (() -> Unit)? = null,
    ) {
        var downRawX = 0f
        var downRawY = 0f
        var downAt = 0L
        var startX = 0
        var startY = 0
        var moved = false
        handle.setOnTouchListener { _, event ->
            val slot = windows[key] ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downAt = event.eventTime
                    startX = slot.params.x
                    startY = slot.params.y
                    moved = false
                    NukeMotionEngine.press(slot.view, true)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) moved = true
                    val vw = slot.params.width.takeIf { it > 0 } ?: slot.view.width.coerceAtLeast(dp(54))
                    val vh = slot.view.height.takeIf { it > 0 } ?: dp(54)
                    slot.params.x = (startX + dx.toInt()).coerceIn(0, maxOf(0, screenWidth() - minOf(vw, screenWidth())))
                    slot.params.y = (startY + dy.toInt()).coerceIn(0, maxOf(0, screenHeight() - minOf(vh, screenHeight())))
                    runCatching { wm.updateViewLayout(slot.view, slot.params) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    NukeMotionEngine.press(slot.view, false)
                    if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                        val heldMs = (event.eventTime - downAt).coerceAtLeast(0L)
                        if (heldMs >= 650L && longPress != null) longPress.invoke() else tap?.invoke()
                    } else if (key == "edge" && event.actionMasked == MotionEvent.ACTION_UP) {
                        // Snap the minimized command rail to the closest physical edge. Reinflate
                        // after the event so TOP/BOTTOM can use a compact horizontal rail.
                        handle.post { snapEdgeToNearest(slot) }
                    }
                    true
                }
                else -> false
            }
        }
    }


    private fun snapEdgeToNearest(slot: WindowSlot) {
        if (windows["edge"] !== slot) return
        val width = slot.params.width.takeIf { it > 0 } ?: slot.view.width.coerceAtLeast(dp(54))
        val height = slot.params.height.takeIf { it > 0 } ?: slot.view.height.coerceAtLeast(dp(54))
        val maxX = maxOf(0, screenWidth() - width)
        val maxY = maxOf(0, screenHeight() - height)
        val left = slot.params.x.coerceAtLeast(0)
        val right = (maxX - slot.params.x).coerceAtLeast(0)
        val top = slot.params.y.coerceAtLeast(0)
        val bottom = (maxY - slot.params.y).coerceAtLeast(0)
        val dock = listOf(EdgeDock.LEFT to left, EdgeDock.RIGHT to right, EdgeDock.TOP to top, EdgeDock.BOTTOM to bottom)
            .minByOrNull { it.second }?.first ?: EdgeDock.LEFT
        val fraction = when (dock) {
            EdgeDock.LEFT, EdgeDock.RIGHT -> if (maxY > 0) slot.params.y.toFloat() / maxY else .35f
            EdgeDock.TOP, EdgeDock.BOTTOM -> if (maxX > 0) slot.params.x.toFloat() / maxX else .5f
        }.takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: .35f
        val targetX = when (dock) { EdgeDock.LEFT -> 0; EdgeDock.RIGHT -> maxX; else -> slot.params.x.coerceIn(0,maxX) }
        val targetY = when (dock) { EdgeDock.TOP -> 0; EdgeDock.BOTTOM -> maxY; else -> slot.params.y.coerceIn(0,maxY) }
        val startX=slot.params.x; val startY=slot.params.y
        android.animation.ValueAnimator.ofFloat(0f,1f).apply {
            duration=190L
            interpolator=android.view.animation.PathInterpolator(.16f,.86f,.25f,1f)
            addUpdateListener { a ->
                if (windows["edge"] !== slot) return@addUpdateListener
                val t=a.animatedValue as Float
                slot.params.x=(startX+(targetX-startX)*t).roundToInt()
                slot.params.y=(startY+(targetY-startY)*t).roundToInt()
                runCatching { wm.updateViewLayout(slot.view,slot.params) }
            }
            doOnEndCompat {
                prefs.edit().putString(K_EDGE_DOCK,dock.name).putFloat(K_EDGE_FRACTION,fraction).remove("edge_x").remove("edge_y").apply()
                removeWindow("edge")
                slot.view.postDelayed({ ensureEdge() },105L)
            }
            start()
        }
    }

    private fun android.animation.ValueAnimator.doOnEndCompat(block: () -> Unit) {
        addListener(object : android.animation.AnimatorListenerAdapter() { override fun onAnimationEnd(animation: android.animation.Animator) = block() })
    }

    private fun View.safeClick(action: () -> Unit) {
        setOnClickListener { if (acceptAction()) action() }
    }

    private fun acceptAction(): Boolean {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastActionAt < TOUCH_DEBOUNCE_MS) return false
        lastActionAt = now
        return true
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams = WindowManager.LayoutParams(
        width,
        height,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
        baseFlags(),
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun baseFlags(): Int = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun hubWidth(): Int {
        val landscape = screenWidth() > screenHeight()
        val fraction = if (landscape) .74f else .95f
        val cap = if (landscape) dp(860) else dp(440)
        val floor = if (landscape) dp(560) else dp(310)
        return minOf(cap, (screenWidth() * fraction).roundToInt()).coerceAtLeast(minOf(floor, screenWidth()))
    }

    private fun hubHeight(): Int {
        val landscape = screenWidth() > screenHeight()
        // The command deck now separates action tiles from full-width switch controls. Reserve
        // enough real height for 40+dp touch targets instead of squeezing switches into icon cells.
        val cap = if (landscape) dp(320) else dp(460)
        val fraction = if (landscape) .84f else .78f
        val floor = if (landscape) dp(296) else dp(420)
        return minOf(cap, (screenHeight() * fraction).roundToInt()).coerceAtLeast(minOf(floor, screenHeight()))
    }

    private fun moduleWidth(): Int {
        val fraction = if (screenWidth() > screenHeight()) .31f else .90f
        val cap = if (screenWidth() > screenHeight()) dp(390) else dp(370)
        return minOf(cap, (screenWidth() * fraction).roundToInt()).coerceAtLeast(minOf(dp(280), screenWidth()))
    }

    private fun moduleHeight(): Int {
        val fraction = if (screenWidth() > screenHeight()) .72f else .66f
        val cap = if (screenWidth() > screenHeight()) dp(400) else dp(590)
        return minOf(cap, (screenHeight() * fraction).roundToInt()).coerceAtLeast(minOf(dp(220), screenHeight()))
    }

    private fun hudScale(): Float = prefs.safeFloat(K_HUD_SCALE, 1f).coerceIn(.85f, 1.15f)
    private fun scaledHubWidth(): Int = minOf((hubWidth() * hudScale()).roundToInt(), (screenWidth() * .97f).roundToInt())
    private fun scaledHubHeight(): Int = minOf((hubHeight() * hudScale()).roundToInt(), (screenHeight() * .80f).roundToInt())
    private fun scaledModuleWidth(): Int = minOf((moduleWidth() * hudScale()).roundToInt(), (screenWidth() * .95f).roundToInt())
    private fun centeredX(width: Int): Int = ((screenWidth() - width) / 2).coerceAtLeast(0)
    private fun displayBounds(): android.graphics.Rect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        runCatching { wm.currentWindowMetrics.bounds }.getOrElse { android.graphics.Rect(0, 0, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels) }
    } else android.graphics.Rect(0, 0, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
    private fun screenWidth(): Int = displayBounds().width().coerceAtLeast(1)
    private fun screenHeight(): Int = displayBounds().height().coerceAtLeast(1)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun showNukeModeBanner() {
        removeWindow("banner")
        val text = TextView(this).apply {
            this.text = "NUKE MODE  //  SESSION ARMED"
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 11f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            background = getDrawable(R.drawable.nuke_mode_badge); alpha = 0f; scaleX = .84f; scaleY = .84f
        }
        val p = params(dp(260), dp(50)).apply {
            x = centeredX(dp(260)); y = dp(42); alpha = .96f; flags = baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        addWindow("banner", text, p)
        text.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240L).withEndAction {
            scope.launch {
                delay(1_100L)
                text.animate().alpha(0f).translationY(-dp(16).toFloat()).setDuration(220L).withEndAction { removeWindow("banner") }.start()
            }
        }.start()
    }

    private suspend fun restoreDisplayWithRetry(
        context: Context = applicationContext,
        maxAttempts: Int = 4,
    ): NukeDisplayProfileController.Result {
        var result = withContext(Dispatchers.IO) {
            runCatching { NukeDisplayProfileController.restoreIfOwned(context) }
                .getOrElse { NukeDisplayProfileController.Result(NukeDisplayProfileController.Outcome.ERROR, "Display restore failed safely") }
        }
        var attempt = 1
        while (attempt < maxAttempts &&
            result.outcome == NukeDisplayProfileController.Outcome.DEFERRED &&
            NukeDisplayProfileController.hasOwnedOverride(context)
        ) {
            // Ask the existing connection manager to re-establish the trusted transport/core, then
            // retry while this user-visible FGS is still alive. initServer() is itself asynchronous.
            runCatching { AdbManager.getInstance(context).initServer() }
            delay(450L + attempt * 450L)
            result = withContext(Dispatchers.IO) {
                runCatching { NukeDisplayProfileController.restoreIfOwned(context) }
                    .getOrElse { NukeDisplayProfileController.Result(NukeDisplayProfileController.Outcome.ERROR, "Display restore failed safely") }
            }
            attempt++
        }
        return result
    }

    private suspend fun stopSession(reason: String) {
        if (stopping) return
        stopping = true
        cancelLoops()
        val local = engine
        val finalState = local?.state?.value
        withTimeoutOrNull(4_500L) { runCatching { local?.restoreSession() } }
        // Remove overlays before restoring size/density so no attached window can be stranded with
        // coordinates from the old emulated display. This also makes foldable/rotation transitions safer.
        removeAllWindowsImmediate()
        val displayRestore = restoreDisplayWithRetry(applicationContext)
        runCatching { local?.releaseLocalResources() }
        displayRestore?.let { result ->
            if (result.outcome == NukeDisplayProfileController.Outcome.ERROR || result.outcome == NukeDisplayProfileController.Outcome.DEFERRED) {
                NukeToast.error(applicationContext, result.message, true)
            }
        }
        finalState?.let { state ->
            val parts = buildList {
                state.lastMeasuredFps?.let { add("FPS ${String.format(Locale.US, "%.0f", it)}") }
                if (state.ramAvailableMb > 0L) add("RAM ${state.ramAvailableMb}MB free")
                batteryTempC?.let { add("TEMP ${String.format(Locale.US, "%.1f°C", it)}") }
                sessionBatterySummary().takeIf { it.isNotBlank() }?.let { add("BAT $it") }
            }
            toastStatus("SUCCESS • Session ended${if (parts.isEmpty()) "" else " • ${parts.joinToString(" • ")}"}", long = true)
        }
        if (prefs.safeBoolean(K_ADAPTIVE_OWN_AWAKE, false)) {
            prefs.edit().putBoolean("hud_keep_awake", false).apply()
        }
        clearSessionMarker(); engine = null; targetPackage = null
        NukeAdManager.markGamingSessionEnded(applicationContext)
        publishRuntime(null)
        Log.i(TAG, "Session stopped: $reason")
        if (foregroundStarted) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            foregroundStarted = false
        }
        stopSelf()
    }

    private fun clearSessionMarker() {
        NukeRuntimeState.setLaunchHandoffActive(false)
        prefs.edit().putBoolean(K_ACTIVE, false).remove(K_ACTIVE_PACKAGE)
            .putBoolean(K_ADAPTIVE_GAME_MODE, false)
            .remove(K_ADAPTIVE_OWN_AWAKE).remove(K_ADAPTIVE_OWN_NETWORK).remove(K_ADAPTIVE_OWN_OEM).apply()
        NukeRuntimeState.update { it.copy(overlayRunning = false, activePackage = null, crosshairEnabled = false) }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        windows.forEach { (key, slot) ->
            when (key) {
                "hub" -> { slot.params.width = scaledHubWidth(); slot.params.height = scaledHubHeight() }
                "edge", "banner", "crosshair" -> Unit
                else -> { slot.params.width = scaledModuleWidth(); slot.params.height = moduleHeight() }
            }
            if (key != "crosshair") {
                slot.params.x = slot.params.x.coerceIn(0, maxOf(0, screenWidth() - (slot.params.width.takeIf { it > 0 } ?: dp(54))))
                slot.params.y = slot.params.y.coerceIn(0, maxOf(0, screenHeight() - dp(54)))
            }
            runCatching { wm.updateViewLayout(slot.view, slot.params) }
        }
        // Reinflate hub so Android can choose layout-land/layout after rotation.
        if (windows.containsKey("hub")) { removeWindow("hub"); openHub() }
        syncCrosshairOverlay()
    }

    override fun onDestroy() {
        NukeRuntimeState.setLaunchHandoffActive(false)
        val unexpectedActiveDestroy = !stopping && ::prefs.isInitialized && prefs.safeBoolean(K_ACTIVE, false)
        val emergencyEngine = engine
        val app = applicationContext
        if (unexpectedActiveDestroy) {
            // If Android destroys an active FGS/service outside the normal End Session path, prefer
            // restoring owned device state over preserving a performance tweak. This detached scope
            // is intentionally independent from `scope`, which is cancelled below.
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                withTimeoutOrNull(4_000L) { runCatching { emergencyEngine?.restoreSession() } }
                restoreDisplayWithRetry(app)
                runCatching { emergencyEngine?.releaseLocalResources() }
            }
        }
        cancelLoops(); switchJob?.cancel()
        runCatching { if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(preferenceListener) }
        removeAllWindows()
        if (!unexpectedActiveDestroy) runCatching { engine?.releaseLocalResources() }
        if (foregroundStarted) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            foregroundStarted = false
        }
        NukeRuntimeState.update { it.copy(overlayRunning = false, crosshairEnabled = false) }
        scope.cancel(); super.onDestroy()
    }

    private fun directoryBytes(root: File): Long = runCatching {
        if (!root.exists()) 0L else if (root.isFile) root.length() else root.listFiles()?.sumOf { directoryBytes(it) } ?: 0L
    }.getOrDefault(0L)

    private fun validLanguage(code: String): String = code.takeIf { candidate -> Tx.supportedLangs.any { it.first == candidate } } ?: "en"
    private fun validPackage(value: String): Boolean = value.length in 3..220 && value.matches(Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$"))
}
