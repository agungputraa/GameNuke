package com.neon.gametweak

import android.app.Activity
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.android.play.core.review.ReviewManagerFactory

object AppUpdateController {

    private const val TAG = "AppUpdate"
    private const val LAUNCHER_KEY = "nuke_app_update_launcher"

    @Volatile var hasUpdate: Boolean = false
        private set
    @Volatile var availableVersion: String? = null
        private set

    private var updateManager: AppUpdateManager? = null
    private var listener: InstallStateUpdatedListener? = null
    private var launcher: ActivityResultLauncher<IntentSenderRequest>? = null

    fun register(activity: ComponentActivity) {
        updateManager = AppUpdateManagerFactory.create(activity.applicationContext)
        @Suppress("UnsafeOptInUsageError")
        launcher = activity.activityResultRegistry.register(
            LAUNCHER_KEY,
            ActivityResultContracts.StartIntentSenderForResult(),
        ) { result ->
            if (result.resultCode != Activity.RESULT_OK) {
                Log.w(TAG, "update flow result=${result.resultCode}")
            }
        }
        listener = InstallStateUpdatedListener { state ->
            if (state.installStatus() == InstallStatus.DOWNLOADED) {
                NukeToast.success(activity, Tx.t("Pembaruan siap dipasang", "Update is ready to install"), long = true)
                runCatching { updateManager?.completeUpdate() }
            }
        }
        listener?.let { updateManager?.registerListener(it) }
        // Network/update query is deferred by MainActivity until after the first frame.
    }

    fun unregister() {
        listener?.let { updateManager?.unregisterListener(it) }
        listener = null
        runCatching { launcher?.unregister() }
        launcher = null
    }

    fun check(activity: Activity) {
        val mgr = updateManager ?: return
        runCatching {
            mgr.appUpdateInfo
                .addOnSuccessListener { info ->
                    val updateAvailable = info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                    val flexAllowed = info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)
                    hasUpdate = updateAvailable && flexAllowed
                    availableVersion = if (hasUpdate) info.availableVersionCode().toString() else null
                    if (info.installStatus() == InstallStatus.DOWNLOADED) {
                        runCatching { mgr.completeUpdate() }
                    }
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "appUpdateInfo failed: ${e.message}")
                }
        }
    }

    fun startFlexibleUpdate(activity: Activity) {
        val mgr = updateManager ?: run {
            NukeToast.unsupported(activity, Tx.t("Pemeriksa pembaruan belum siap.", "Update checker is not ready."))
            return
        }
        val l = launcher ?: run {
            NukeToast.unsupported(activity, Tx.t("Alur pembaruan belum siap.", "Update flow is not ready."))
            return
        }
        runCatching {
            mgr.appUpdateInfo.addOnSuccessListener { info ->
                if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                    info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)
                ) {
                    runCatching {
                        mgr.startUpdateFlowForResult(
                            info,
                            l,
                            AppUpdateOptions.newBuilder(AppUpdateType.FLEXIBLE).build(),
                        )
                    }.onSuccess { NukeToast.success(activity, Tx.t("Alur pembaruan dibuka.", "Update flow opened.")) }
                        .onFailure {
                            Log.w(TAG, "startUpdateFlow failed: ${it.message}")
                            NukeToast.error(activity, Tx.t("Pembaruan gagal dibuka.", "Update flow could not be opened."))
                        }
                } else {
                    NukeToast.success(activity, Tx.t("Sudah versi terbaru", "Game Nuke is already up to date"))
                }
            }.addOnFailureListener { error ->
                Log.w(TAG, "user update check failed: ${error.message}")
                NukeToast.error(activity, Tx.t("Pemeriksaan pembaruan gagal.", "Update check failed."))
            }
        }.onFailure {
            Log.w(TAG, "user update flow failed: ${it.message}")
            NukeToast.error(activity, Tx.t("Pembaruan gagal diproses.", "Update could not be processed."))
        }
    }

    fun launchInAppReview(activity: Activity, onComplete: (() -> Unit)? = null) {
        val reviewManager = ReviewManagerFactory.create(activity.applicationContext)
        runCatching {
            reviewManager.requestReviewFlow().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val info = task.result
                    reviewManager.launchReviewFlow(activity, info).addOnCompleteListener {
                        onComplete?.invoke()
                    }
                } else {
                    NukeToast.unsupported(activity, Tx.t("Review tidak tersedia", "Review is not available"))
                    onComplete?.invoke()
                }
            }
        }.onFailure {
            NukeToast.error(activity, Tx.t("Error review: ${it.message}", "Review error: ${it.message}"))
            onComplete?.invoke()
        }
    }
}
