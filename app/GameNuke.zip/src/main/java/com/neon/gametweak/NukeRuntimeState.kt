package com.neon.gametweak

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Small process-local bridge shared by the main app and the floating cockpit.
 * Persistent preferences remain the source of truth across process death; this flow keeps
 * foreground UI surfaces synchronized without polling while the process is alive.
 */
object NukeRuntimeState {
    data class Snapshot(
        val overlayRunning: Boolean = false,
        val activePackage: String? = null,
        val language: String = "en",
        val crosshairEnabled: Boolean = false,
        val enabledModules: Int = 0,
        val currentHz: Int = 0,
        val maxHz: Int = 0,
        val lastFps: Float? = null,
        val phase: String = "IDLE",
        val message: String = "CORE STANDBY",
    )

    private val _state = MutableStateFlow(Snapshot())
    val state: StateFlow<Snapshot> = _state.asStateFlow()

    // Process-local guard covering the small gap between applying a display profile and the
    // floating service publishing overlayRunning=true. Stale-recovery must not race that handoff.
    private val launchHandoff = AtomicBoolean(false)

    fun setLaunchHandoffActive(active: Boolean) {
        launchHandoff.set(active)
    }

    fun isLaunchHandoffActive(): Boolean = launchHandoff.get()

    fun publish(value: Snapshot) {
        _state.value = value
    }

    fun update(transform: (Snapshot) -> Snapshot) {
        _state.value = transform(_state.value)
    }
}
