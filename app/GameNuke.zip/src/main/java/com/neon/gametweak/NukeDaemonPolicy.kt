package com.neon.gametweak

/**
 * Strict local-core command gate.
 *
 * This deliberately validates complete command grammars instead of broad prefixes. The persistent
 * core is a narrow Game Nuke capability transport, never a general-purpose ADB shell.
 */
object NukeDaemonPolicy {
    private val packageName = Regex("^[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+$")
    private val numeric = Regex("^-?\\d+(?:\\.\\d+)?$")
    private val positiveInteger = Regex("^\\d{1,14}$")
    private val gameOverlayConfig = Regex("^[A-Za-z0-9_.,:=+\\-]{1,2048}$")
    private val cpuClockPath = Regex("^cat /sys/devices/system/cpu/cpu(?:[0-9]|[12][0-9]|3[01])/cpufreq/scaling_cur_freq$")

    private val readableSettings = setOf(
        "system:peak_refresh_rate",
        "system:min_refresh_rate",
        "system:accelerometer_rotation",
        "system:user_rotation",
        "global:low_power",
    )
    private val writableNumericSettings = readableSettings

    fun isAllowed(command: String): Boolean {
        val c = command.trim()
        if (c.isEmpty() || c.length > 4096 || c.contains('\u0000')) return false
        // No shell composition, redirection, substitution, multiline commands or chaining.
        if (Regex("[;&|`<>]|\\$\\(|\\n|\\r").containsMatchIn(c)) return false

        if (c in setOf(
                "am compact system", "am help", "pm help", "cmd package help",
                "cmd netpolicy help", "cmd netpolicy get restrict-background", "cmd power help",
                "cat /proc/stat", "dumpsys cpuinfo", "dumpsys activity activities", "dumpsys window",
                "dumpsys thermalservice", "ps -A -o PID,RSS,NAME", "wm size", "wm density",
                "dumpsys SurfaceFlinger --timestats -clear -enable",
                "dumpsys SurfaceFlinger --timestats -dump",
                "dumpsys SurfaceFlinger --timestats -disable",
                "getprop debug.graphics.game_default_frame_rate.disabled",
            )
        ) return true

        cpuClockPath.matchEntire(c)?.let { return true }

        Regex("^settings get (system|global|secure) ([A-Za-z0-9_.-]{1,96})$").matchEntire(c)?.let { m ->
            return "${m.groupValues[1]}:${m.groupValues[2]}" in readableSettings
        }
        Regex("^settings (put|delete) (system|global) ([A-Za-z0-9_.-]{1,96})(?: (-?\\d+(?:\\.\\d+)?))?$").matchEntire(c)?.let { m ->
            val op = m.groupValues[1]
            val key = "${m.groupValues[2]}:${m.groupValues[3]}"
            if (key !in writableNumericSettings) return false
            return if (op == "delete") m.groupValues[4].isEmpty() else numeric.matches(m.groupValues[4])
        }
        Regex("^setprop debug\\.graphics\\.game_default_frame_rate\\.disabled (true|false)$").matchEntire(c)?.let { return true }
        Regex("^cmd power set-mode ([01])$").matchEntire(c)?.let { return true }
        Regex("^cmd netpolicy set restrict-background (true|false)$").matchEntire(c)?.let { return true }
        Regex("^cmd wifi force-low-latency-mode (enabled|disabled)$").matchEntire(c)?.let { return true }
        Regex("^cmd game list-modes ([A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+)$").matchEntire(c)?.let { return packageName.matches(it.groupValues[1]) }
        Regex("^cmd game mode (standard|performance|battery|custom) ([A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+)$").matchEntire(c)?.let { return packageName.matches(it.groupValues[2]) }
        Regex("^am kill ([A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+)$").matchEntire(c)?.let { return packageName.matches(it.groupValues[1]) }
        Regex("^pm trim-caches (\\d{1,14})$").matchEntire(c)?.let { return positiveInteger.matches(it.groupValues[1]) }
        Regex("^cmd package compile -f -m (speed|speed-profile) ([A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+)$").matchEntire(c)?.let { return packageName.matches(it.groupValues[2]) }
        Regex("^device_config (get|delete) game_overlay ([A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+)$").matchEntire(c)?.let { return packageName.matches(it.groupValues[2]) }
        Regex("^device_config put game_overlay ([A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+) ([A-Za-z0-9_.,:=+\\-]{1,2048})$").matchEntire(c)?.let {
            return packageName.matches(it.groupValues[1]) && gameOverlayConfig.matches(it.groupValues[2])
        }
        Regex("^wm size (reset|(\\d{3,4})x(\\d{3,4}))$").matchEntire(c)?.let { match ->
            if (match.groupValues[1] == "reset") return true
            val width = match.groupValues[2].toIntOrNull() ?: return false
            val height = match.groupValues[3].toIntOrNull() ?: return false
            return width in 480..6000 && height in 480..6000
        }
        Regex("^wm density (reset|\\d{2,4})$").matchEntire(c)?.let { match ->
            if (match.groupValues[1] == "reset") return true
            return match.groupValues[1].toIntOrNull() in 120..1000
        }

        return false
    }
}
