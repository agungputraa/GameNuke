package com.neon.gametweak

import android.net.LocalServerSocket
import android.net.LocalSocket
import android.os.Process
import android.util.Base64
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/**
 * Local persistent shell core, bootstrapped only after an explicit, authorized ADB session.
 * It is not a hidden Wireless-ADB bypass and does not survive a reboot. The socket authenticates
 * callers by Android UID and exposes only NukeDaemonPolicy-approved operations.
 */
object NukeShellDaemon {
    private const val PACKAGE="com.neon.gametweak"
    private const val TAG="GameNukeCore"
    private val running=AtomicBoolean(true)
    private val lastKnownPackageUid=AtomicInteger(-1)
    private val pool=Executors.newFixedThreadPool(3)

    @JvmStatic fun main(args:Array<String>) {
        if(Process.myUid()!=2000 && Process.myUid()!=0) return
        val server=runCatching { LocalServerSocket(NukeDaemonClient.SOCKET_NAME) }.getOrNull() ?: return
        thread(name="Nuke-Core-Watchdog",isDaemon=true) {
            var definitiveMissingPasses=0
            while(running.get()) {
                when(val uid=resolvePackageUid()) {
                    -1 -> {
                        definitiveMissingPasses++
                        Log.w(TAG,"Package lookup says Game Nuke is missing ($definitiveMissingPasses/4)")
                        if(definitiveMissingPasses>=4) { running.set(false); runCatching{server.close()}; break }
                    }
                    -2 -> Log.w(TAG,"Package UID lookup transiently unavailable; keeping local core alive")
                    else -> {
                        lastKnownPackageUid.set(uid)
                        definitiveMissingPasses=0
                    }
                }
                try{Thread.sleep(15000)}catch(_:InterruptedException){break}
            }
        }
        try {
            while(running.get()) {
                val socket=runCatching{server.accept()}.getOrNull() ?: break
                pool.execute { handle(socket) }
            }
        } finally { running.set(false); runCatching{server.close()}; pool.shutdownNow() }
    }

    private fun handle(socket:LocalSocket) {
        try {
            socket.soTimeout=125000
            val resolved=resolvePackageUid()
            if(resolved>=0) lastKnownPackageUid.set(resolved)
            val expected=if(resolved>=0) resolved else lastKnownPackageUid.get()
            val peer=runCatching{socket.peerCredentials.uid}.getOrDefault(-1)
            if(expected<0 || peer!=expected) { socket.outputStream.bufferedWriter().use{it.write("DENIED\n")}; return }
            val line=BufferedReader(InputStreamReader(socket.inputStream)).readLine().orEmpty()
            val response=when {
                line=="PING" -> "PONG|${Process.myPid()}"
                line=="STOP" -> { running.set(false); "BYE" }
                line.startsWith("EXEC|") -> executeRequest(line)
                else -> "ERROR|PROTOCOL"
            }
            socket.outputStream.bufferedWriter().use{it.write(response);it.write("\n");it.flush()}
            if(line=="STOP") thread(isDaemon=true) { try{Thread.sleep(80)}catch(_:Throwable){}; Process.killProcess(Process.myPid()) }
        } catch(_:Throwable) {} finally { runCatching{socket.close()} }
    }

    private fun executeRequest(line:String):String {
        val p=line.split('|',limit=3); if(p.size!=3)return "ERROR|PROTOCOL"
        val timeout=p[1].toLongOrNull()?.coerceIn(500,120000) ?: 7500L
        val command=runCatching{String(Base64.decode(p[2],Base64.NO_WRAP),Charsets.UTF_8)}.getOrDefault("")
        if(!NukeDaemonPolicy.isAllowed(command)) return "ERROR|BLOCKED"
        val proc=runCatching{ProcessBuilder("/system/bin/sh","-c",command).redirectErrorStream(true).start()}.getOrNull()
            ?: return "RESULT|-1|0|"
        val out=StringBuilder(); val reader=thread(isDaemon=true,name="Nuke-Core-Read") {
            runCatching { proc.inputStream.bufferedReader().useLines { seq -> seq.takeWhile{out.length<131072}.forEach{lineOut-> if(out.isNotEmpty())out.append('\n');out.append(lineOut.take(4096))} } }
        }
        val completed=runCatching{proc.waitFor(timeout,TimeUnit.MILLISECONDS)}.getOrDefault(false)
        if(!completed) runCatching{proc.destroyForcibly()}
        runCatching{reader.join(350)}
        val code=if(completed)runCatching{proc.exitValue()}.getOrDefault(-1) else -1
        val encoded=Base64.encodeToString(out.toString().take(131072).toByteArray(Charsets.UTF_8),Base64.NO_WRAP)
        return "RESULT|$code|${if(completed)0 else 1}|$encoded"
    }

    /** >=0 valid UID, -1 package definitively absent, -2 transient command/parse failure. */
    private fun resolvePackageUid():Int {
        val p=runCatching{
            ProcessBuilder("/system/bin/sh","-c","cmd package list packages -U $PACKAGE").redirectErrorStream(true).start()
        }.getOrElse {
            Log.w(TAG,"Unable to start package UID lookup",it)
            return -2
        }
        val completed=runCatching{p.waitFor(2,TimeUnit.SECONDS)}.getOrDefault(false)
        if(!completed) {
            runCatching{p.destroyForcibly()}
            Log.w(TAG,"Package UID lookup timed out")
            return -2
        }
        val text=runCatching{p.inputStream.bufferedReader().readText()}.getOrDefault("")
        if(!text.contains("package:$PACKAGE")) return -1
        return Regex("uid:(\\d+)").find(text)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: -2
    }
}
