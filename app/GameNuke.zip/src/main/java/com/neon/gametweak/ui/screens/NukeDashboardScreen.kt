package com.neon.gametweak.ui.screens

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.WindowManager
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Adb
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.DeveloperMode
import androidx.compose.material.icons.rounded.Gamepad
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neon.gametweak.AdbManager
import com.neon.gametweak.BuildConfig
import com.neon.gametweak.NukeGamingShellGateway
import com.neon.gametweak.NukeLocalCpuSampler
import com.neon.gametweak.NukeRuntimeState
import com.neon.gametweak.NukeToast
import com.neon.gametweak.Tx
import com.neon.gametweak.safeBoolean
import com.neon.gametweak.ui.theme.Neon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private data class CommandCenterTelemetry(
    val adbConnected: Boolean = false,
    val cpuLoad: Int? = null,
    val ramUsedPercent: Int = 0,
    val ramUsedGb: Float = 0f,
    val ramTotalGb: Float = 0f,
    val storageFreeGb: Float = 0f,
    val storageTotalGb: Float = 0f,
    val batteryPercent: Int = 0,
    val temperatureC: Float = 0f,
    val currentHz: Int = 0,
    val maxHz: Int = 0,
    val network: String = "OFFLINE",
    val overlayReady: Boolean = false,
    val sessionReady: Boolean = false,
    val dndReady: Boolean = false,
)

private val ReactorShape = CutCornerShape(topStart = 24.dp, topEnd = 5.dp, bottomStart = 5.dp, bottomEnd = 24.dp)
private val ReactorSmall = CutCornerShape(topStart = 12.dp, topEnd = 2.dp, bottomStart = 2.dp, bottomEnd = 12.dp)

/**
 * Main Game Nuke command center. The first screen is deliberately not a collection of generic
 * Android tweak cards: it shows session readiness, measured telemetry, and the few controls a
 * player needs before arming the floating gaming core.
 */
@Composable
fun DashboardScreen(
    adbManager: AdbManager,
    onOpenDevOptions: () -> Unit,
    onOpenGames: () -> Unit = {},
    onOpenCleaner: () -> Unit = {},
    onOpenMonitor: () -> Unit = {},
) {
    val context = LocalContext.current
    val gateway = remember(adbManager) { NukeGamingShellGateway(adbManager) }
    var telemetry by remember { mutableStateOf(CommandCenterTelemetry()) }

    LaunchedEffect(Unit) {
        while (true) {
            telemetry = withContext(Dispatchers.IO) {
                readCommandCenterTelemetry(context, adbManager, gateway)
            }
            delay(1_350L)
        }
    }

    val readyCount = listOf(
        telemetry.adbConnected,
        telemetry.overlayReady,
        telemetry.sessionReady,
        telemetry.dndReady,
    ).count { it }
    val readiness = readyCount / 4f

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Neon.Bg),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ReactorCommandHero(
                telemetry = telemetry,
                readiness = readiness,
                readyCount = readyCount,
                onArm = onOpenGames,
                onAdb = {
                    adbManager.startNetworkScanner()
                    adbManager.initServer()
                    if (!adbManager.hasPairedBefore()) {
                        onOpenDevOptions()
                    } else {
                        NukeToast.success(context, Tx.t("Permintaan sambung ulang kontrol perangkat dikirim.", "Device-control reconnect request started."))
                    }
                },
            )
        }

        item {
            SectionRail("LIVE ENGINE", "MEASURED TELEMETRY")
            Spacer(Modifier.height(8.dp))
            DualGaugeDeck(telemetry)
        }

        item {
            TelemetryMatrix(telemetry)
        }

        item {
            SectionRail("SESSION READINESS", "$readyCount/4 SYSTEM PATHS")
            Spacer(Modifier.height(8.dp))
            ReadinessDeck(
                context = context,
                telemetry = telemetry,
                onAdb = {
                    adbManager.startNetworkScanner()
                    adbManager.initServer()
                    if (!adbManager.hasPairedBefore()) {
                        onOpenDevOptions()
                    } else {
                        NukeToast.success(context, Tx.t("Permintaan sambung ulang kontrol perangkat dikirim.", "Device-control reconnect request started."))
                    }
                },
            )
        }

        item {
            SectionRail("NUKE DECK", "HIGH-VALUE CONTROLS")
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandTile(
                    "GAME SPACE", "Choose a game and arm the HUD", Icons.Rounded.Gamepad,
                    Neon.Accent, Modifier.weight(1f), onOpenGames,
                )
                CommandTile(
                    "DEEP CLEAN", "Storage + memory preparation", Icons.Rounded.CleaningServices,
                    Color(0xFFFFC857), Modifier.weight(1f), onOpenCleaner,
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandTile(
                    "SYSTEM MONITOR", "Processes and memory pressure", Icons.Rounded.Memory,
                    Color(0xFF35F2FF), Modifier.weight(1f), onOpenMonitor,
                )
                CommandTile(
                    "DEVICE CONTROL", if (telemetry.adbConnected) "Extended controls ready" else "Connect advanced controls",
                    Icons.Rounded.Adb, if (telemetry.adbConnected) Neon.Accent else Color(0xFFFF7A59),
                    Modifier.weight(1f),
                ) {
                    adbManager.startNetworkScanner()
                    onOpenDevOptions()
                }
            }
        }

        item {
            SystemIntelligenceCard(telemetry)
        }
    }
}

@Composable
private fun ReactorCommandHero(
    telemetry: CommandCenterTelemetry,
    readiness: Float,
    readyCount: Int,
    onArm: () -> Unit,
    onAdb: () -> Unit,
) {
    val infinite = rememberInfiniteTransition(label = "reactor")
    val pulse by infinite.animateFloat(
        0.44f, 0.72f,
        animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "reactorPulse",
    )
    val accent = if (telemetry.adbConnected) Neon.Accent else Color(0xFFFFC857)

    Box(
        Modifier.fillMaxWidth()
            .clip(ReactorShape)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        accent.copy(alpha = 0.18f),
                        Color(0xFF0B1A15),
                        Color(0xFF040A08),
                        Color(0xFF10101A),
                    ),
                ),
            )
            .border(1.dp, accent.copy(alpha = 0.42f + pulse * 0.26f), ReactorShape)
            .padding(16.dp),
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(62.dp)
                        .clip(CutCornerShape(topStart = 19.dp, topEnd = 2.dp, bottomStart = 2.dp, bottomEnd = 19.dp))
                        .background(Brush.radialGradient(listOf(accent.copy(alpha = 0.28f + pulse * .12f), Color(0xFF07100D), Color(0xFF020504))))
                        .border(1.dp, accent.copy(alpha = .58f), ReactorSmall),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("GN", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Text("CORE", color = accent, fontSize = 7.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.4.sp)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("NUCLEAR COMMAND CENTER", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        if (telemetry.adbConnected) "EXTENDED CONTROL READY" else "STANDARD CONTROL READY",
                        color = accent,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = .8.sp,
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "Game Nuke v${BuildConfig.VERSION_NAME} • adaptive gaming control",
                        color = Neon.TextDim,
                        fontSize = 10.sp,
                        maxLines = 2,
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("READINESS", color = Neon.TextDim, fontSize = 8.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.5.sp)
                        Spacer(Modifier.weight(1f))
                        Text("$readyCount / 4", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(Modifier.height(5.dp))
                    SegmentedProgress(readiness, accent)
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReactorButton("ARM GAME SESSION", Icons.Rounded.PlayArrow, Neon.Accent, Modifier.weight(1.45f), onArm)
                ReactorButton(
                    if (telemetry.adbConnected) "CONTROL READY" else "CONNECT",
                    Icons.Rounded.DeveloperMode,
                    accent,
                    Modifier.weight(1f),
                    onAdb,
                )
            }
        }
    }
}

@Composable
private fun DualGaugeDeck(telemetry: CommandCenterTelemetry) {
    val cpu = telemetry.cpuLoad ?: 0
    val ram = telemetry.ramUsedPercent
    Box(
        Modifier.fillMaxWidth().clip(ReactorShape)
            .background(Brush.verticalGradient(listOf(Color(0xFF0B1814), Color(0xFF050908))))
            .border(1.dp, Color(0xFF1A493C), ReactorShape)
            .padding(horizontal = 12.dp, vertical = 13.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            AnimatedSpeedometer(
                label = "CPU LOAD",
                value = cpu,
                valueText = telemetry.cpuLoad?.let { "$it%" } ?: "--",
                accent = Color(0xFF35F2FF),
                modifier = Modifier.weight(1f),
            )
            Column(Modifier.width(92.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("REACTOR", color = Neon.TextDim, fontSize = 7.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (telemetry.temperatureC > 43f) "THERMAL\nGUARD" else "SYSTEM\nNOMINAL",
                    color = if (telemetry.temperatureC > 43f) Color(0xFFFF5D67) else Neon.Accent,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Black,
                    lineHeight = 14.sp,
                )
                Spacer(Modifier.height(4.dp))
                Text("${telemetry.currentHz} / ${telemetry.maxHz} HZ", color = Color.White, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
            AnimatedSpeedometer(
                label = "RAM USAGE",
                value = ram,
                valueText = "$ram%",
                accent = Neon.Accent,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun AnimatedSpeedometer(
    label: String,
    value: Int,
    valueText: String,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    val animated by animateFloatAsState(
        targetValue = value.coerceIn(0, 100).toFloat(),
        animationSpec = tween(850, easing = FastOutSlowInEasing),
        label = "gauge-$label",
    )
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 7.dp.toPx()
                val start = 145f
                val sweep = 250f
                drawArc(
                    color = Color(0xFF1B2C27), startAngle = start, sweepAngle = sweep,
                    useCenter = false, style = Stroke(stroke, cap = StrokeCap.Round),
                )
                drawArc(
                    brush = Brush.sweepGradient(listOf(accent.copy(alpha = .25f), accent)),
                    startAngle = start, sweepAngle = sweep * (animated / 100f),
                    useCenter = false, style = Stroke(stroke, cap = StrokeCap.Round),
                )
                val radius = size.minDimension * .40f
                for (i in 0..10) {
                    val angle = Math.toRadians((start + sweep * (i / 10f)).toDouble())
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val outer = Offset(c.x + cos(angle).toFloat() * radius, c.y + sin(angle).toFloat() * radius)
                    val innerR = radius - if (i % 5 == 0) 8.dp.toPx() else 5.dp.toPx()
                    val inner = Offset(c.x + cos(angle).toFloat() * innerR, c.y + sin(angle).toFloat() * innerR)
                    drawLine(if (i / 10f <= animated / 100f) accent.copy(alpha = .78f) else Color(0xFF355047), inner, outer, strokeWidth = 1.2.dp.toPx())
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(valueText, color = accent, fontSize = 21.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                Text(label, color = Neon.TextDim, fontSize = 7.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 1.1.sp)
            }
        }
    }
}

@Composable
private fun TelemetryMatrix(telemetry: CommandCenterTelemetry) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            MetricTile("DISPLAY", "${telemetry.currentHz}/${telemetry.maxHz}Hz", Icons.Rounded.Speed, Color(0xFF35F2FF), Modifier.weight(1f))
            MetricTile("THERMAL", "${"%.1f".format(telemetry.temperatureC)}°C", Icons.Rounded.Thermostat, if (telemetry.temperatureC > 43f) Color(0xFFFF5D67) else Neon.Accent, Modifier.weight(1f))
            MetricTile("BATTERY", "${telemetry.batteryPercent}%", Icons.Rounded.BatteryChargingFull, Color(0xFFFFC857), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            MetricTile("RAM", "${"%.1f".format(telemetry.ramUsedGb)}/${"%.1f".format(telemetry.ramTotalGb)}G", Icons.Rounded.Memory, Neon.Accent, Modifier.weight(1f))
            MetricTile("STORAGE", "${"%.1f".format(telemetry.storageFreeGb)}G FREE", Icons.Rounded.Storage, Color(0xFF9877FF), Modifier.weight(1f))
            MetricTile("NETWORK", telemetry.network, Icons.Rounded.Wifi, Color(0xFF35F2FF), Modifier.weight(1f))
        }
    }
}

@Composable
private fun ReadinessDeck(context: Context, telemetry: CommandCenterTelemetry, onAdb: () -> Unit) {
    val rows = listOf(
        ReadinessItem("DEVICE CONTROL", telemetry.adbConnected, "Extended compatibility", Icons.Rounded.Tune, onAdb),
        ReadinessItem("FLOATING HUD", telemetry.overlayReady, "Overlay permission", Icons.Rounded.Layers) {
            runCatching { context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${context.packageName}"))) }
        },
        ReadinessItem("SESSION TRACK", telemetry.sessionReady, "Gaming session active", Icons.Rounded.Security, onAdb),
        ReadinessItem("GAME FOCUS", telemetry.dndReady, "DND policy access", Icons.Rounded.NotificationsOff) {
            runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        },
    )
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                pair.forEach { ReadinessTile(it, Modifier.weight(1f)) }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

private data class ReadinessItem(val title: String, val ready: Boolean, val detail: String, val icon: ImageVector, val onClick: () -> Unit)

@Composable
private fun ReadinessTile(item: ReadinessItem, modifier: Modifier = Modifier) {
    val accent = if (item.ready) Neon.Accent else Color(0xFFFFC857)
    Row(
        modifier.clip(ReactorSmall).background(Color(0xFF08110E))
            .border(1.dp, accent.copy(alpha = .28f), ReactorSmall)
            .clickable(onClick = item.onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(30.dp).clip(ReactorSmall).background(accent.copy(alpha = .10f)), contentAlignment = Alignment.Center) {
            Icon(item.icon, null, tint = accent, modifier = Modifier.size(17.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black, maxLines = 1)
            Text(item.detail, color = Neon.TextDim, fontSize = 7.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
    }
}

@Composable
private fun CommandTile(title: String, detail: String, icon: ImageVector, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(104.dp).clip(ReactorSmall)
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = .09f), Color(0xFF0A1512), Color(0xFF050807))))
            .border(1.dp, accent.copy(alpha = .32f), ReactorSmall)
            .clickable(onClick = onClick).padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(32.dp).clip(ReactorSmall).background(accent.copy(alpha = .10f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.weight(1f))
            Text("OPEN >", color = accent, fontSize = 7.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
        }
        Spacer(Modifier.height(9.dp))
        Text(title, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = .4.sp)
        Spacer(Modifier.height(2.dp))
        Text(detail, color = Neon.TextDim, fontSize = 8.sp, lineHeight = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SystemIntelligenceCard(telemetry: CommandCenterTelemetry) {
    val accent = if (telemetry.adbConnected) Neon.Accent else Color(0xFFFFC857)
    Column(
        Modifier.fillMaxWidth().clip(ReactorShape).background(Color(0xFF050B09))
            .border(1.dp, Color(0xFF163B31), ReactorShape).padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Tune, null, tint = accent, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(8.dp))
            Text("NUKE INTELLIGENCE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = 1.4.sp)
            Spacer(Modifier.weight(1f))
            Text(if (telemetry.adbConnected) "EXTENDED" else "STANDARD", color = accent, fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (telemetry.adbConnected) {
                Tx.t(
                    "Kontrol perangkat aktif. Game Nuke dapat memakai optimasi yang didukung perangkat, memverifikasi hasil, mengukur telemetry, lalu memulihkan perubahan milik sesi.",
                    "Device control is active. Game Nuke can use supported optimizations, verify results, measure telemetry, and restore session-owned changes.",
                )
            } else {
                Tx.t(
                    "Game Nuke tetap memantau RAM, suhu, baterai, display, dan status sesi. Hubungkan kontrol lanjutan jika perangkat mendukung optimasi tambahan.",
                    "Game Nuke still monitors RAM, temperature, battery, display, and session status. Connect advanced control when the device supports additional optimizations.",
                )
            },
            color = Neon.TextDim, fontSize = 10.sp, lineHeight = 14.sp,
        )
    }
}

@Composable
private fun MetricTile(label: String, value: String, icon: ImageVector, accent: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(ReactorSmall).background(Color(0xFF07100D)).border(1.dp, Color(0xFF173A31), ReactorSmall).padding(9.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(5.dp))
            Text(label, color = Neon.TextDim, fontSize = 6.7.sp, fontFamily = FontFamily.Monospace, letterSpacing = .8.sp, maxLines = 1)
        }
        Spacer(Modifier.height(4.dp))
        Text(value, color = accent, fontSize = 10.5.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ReactorButton(text: String, icon: ImageVector, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(44.dp).clip(ReactorSmall).background(accent.copy(alpha = .10f))
            .border(1.dp, accent.copy(alpha = .55f), ReactorSmall).clickable(onClick = onClick).padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(7.dp))
        Text(text, color = accent, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = .7.sp, maxLines = 1)
    }
}

@Composable
private fun SectionRail(title: String, meta: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(18.dp).height(2.dp).background(Neon.Accent))
        Spacer(Modifier.width(7.dp))
        Text(title, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(1.dp).background(Color(0xFF1B493C)))
        Spacer(Modifier.width(8.dp))
        Text(meta, color = Neon.TextDim, fontSize = 6.7.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun SegmentedProgress(progress: Float, accent: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(12) { index ->
            val on = (index + 1) / 12f <= progress + .02f
            Box(Modifier.weight(1f).height(4.dp).clip(CutCornerShape(1.dp)).background(if (on) accent else Color(0xFF1D2A26)))
        }
    }
}

private fun readCommandCenterTelemetry(
    context: Context,
    adbManager: AdbManager,
    gateway: NukeGamingShellGateway,
): CommandCenterTelemetry {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    val info = ActivityManager.MemoryInfo()
    runCatching { am?.getMemoryInfo(info) }
    val totalRam = info.totalMem.coerceAtLeast(0L)
    val usedRam = (totalRam - info.availMem.coerceAtLeast(0L)).coerceAtLeast(0L)
    val ramUsedPercent = if (totalRam > 0L) ((usedRam.toDouble() / totalRam.toDouble()) * 100.0).roundToInt().coerceIn(0, 100) else 0

    val stat = runCatching { StatFs(Environment.getDataDirectory().path) }.getOrNull()
    val storageFree = stat?.availableBytes ?: 0L
    val storageTotal = stat?.totalBytes ?: 0L

    val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val batteryLevel = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val batteryScale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val batteryPercent = if (batteryLevel >= 0 && batteryScale > 0) (batteryLevel * 100f / batteryScale).roundToInt().coerceIn(0, 100) else 0
    val temperature = (battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

    val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    @Suppress("DEPRECATION")
    val display = wm?.defaultDisplay
    val currentHz = runCatching { display?.refreshRate?.roundToInt() ?: 0 }.getOrDefault(0)
    val maxHz = runCatching { display?.supportedModes?.maxOfOrNull { it.refreshRate }?.roundToInt() ?: currentHz }.getOrDefault(currentHz)

    val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    val networkLabel = runCatching {
        val cm = connectivity ?: return@runCatching "OFFLINE"
        val network = cm.activeNetwork ?: return@runCatching "OFFLINE"
        val caps = cm.getNetworkCapabilities(network) ?: return@runCatching "ONLINE"
        when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MOBILE"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "LAN"
            else -> "ONLINE"
        }
    }.getOrDefault("OFFLINE")

    val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    val adbConnected = runCatching { adbManager.isConnected() }.getOrDefault(false)
    val cpu = runCatching { if (adbConnected) gateway.readCpuLoadPercent() else null }.getOrNull() ?: NukeLocalCpuSampler.readPercent()

    return CommandCenterTelemetry(
        adbConnected = adbConnected,
        cpuLoad = cpu,
        ramUsedPercent = ramUsedPercent,
        ramUsedGb = usedRam / 1_073_741_824f,
        ramTotalGb = totalRam / 1_073_741_824f,
        storageFreeGb = storageFree / 1_073_741_824f,
        storageTotalGb = storageTotal / 1_073_741_824f,
        batteryPercent = batteryPercent,
        temperatureC = temperature,
        currentHz = currentHz,
        maxHz = maxHz,
        network = networkLabel,
        overlayReady = Settings.canDrawOverlays(context),
        sessionReady = NukeRuntimeState.state.value.overlayRunning ||
            context.getSharedPreferences("NukePrefs", Context.MODE_PRIVATE).safeBoolean("overlay_active_session", false),
        dndReady = notificationManager?.isNotificationPolicyAccessGranted == true,
    )
}
