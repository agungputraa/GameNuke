package com.neon.gametweak

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.FrameLayout

/** Compact edge handle. It intentionally exposes only the geometric N reactor mark. */
class NukeEdgeRailLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0,
): FrameLayout(context, attrs, defStyleAttr) {
    private val d = resources.displayMetrics.density
    private val path = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = .9f*d; color = NukeHudPalette.Green }
    init { setWillNotDraw(false) }
    override fun onSizeChanged(w:Int,h:Int,ow:Int,oh:Int){
        super.onSizeChanged(w,h,ow,oh); path.rewind(); if(w<=1||h<=1)return
        val c = minOf(9f*d, minOf(w,h)*.22f)
        path.moveTo(c,0f); path.lineTo(w-c*.55f,0f); path.lineTo(w.toFloat(),c)
        path.lineTo(w.toFloat(),h-c); path.lineTo(w-c,h.toFloat()); path.lineTo(c*.55f,h.toFloat()); path.lineTo(0f,h-c); path.lineTo(0f,c); path.close()
        fill.shader = if(h>=w) LinearGradient(0f,0f,w.toFloat(),0f,intArrayOf(NukeHudPalette.PanelRaised,NukeHudPalette.Void),null,Shader.TileMode.CLAMP)
        else LinearGradient(0f,0f,0f,h.toFloat(),intArrayOf(NukeHudPalette.PanelRaised,NukeHudPalette.Void),null,Shader.TileMode.CLAMP)
    }
    override fun onDraw(canvas:Canvas){ super.onDraw(canvas); canvas.drawPath(path,fill); canvas.drawPath(path,stroke) }
}
