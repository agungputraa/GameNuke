package com.neon.gametweak

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.min

/** Compact geometric N reactor mark used by the edge rail and main cockpit. */
class NukeReactorCoreView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : View(context, attrs, defStyleAttr) {
    enum class Status { OFFLINE, DEGRADED, ONLINE }

    private val d = resources.displayMetrics.density
    private val shell = Path()
    private val n = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * d
    }
    private var pulse = .34f
    private var animator: ValueAnimator? = null
    private var status = Status.OFFLINE

    fun setStatus(value: Status) {
        if (status == value) return
        status = value
        when (value) {
            Status.ONLINE -> ignite()
            Status.DEGRADED -> ignite(2_600L)
            Status.OFFLINE -> extinguish()
        }
        alpha = if (value == Status.OFFLINE) .58f else 1f
        invalidate()
    }

    fun ignite(durationMs: Long = 1_900L) {
        if (animator != null) return
        animator = ValueAnimator.ofFloat(.20f, 1f, .20f).apply {
            duration = durationMs
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun extinguish() {
        animator?.cancel()
        animator = null
        pulse = .24f
        invalidate()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w < 2f || h < 2f) return
        val cut = min(w, h) * .22f
        val accent = when (status) {
            Status.ONLINE -> NukeHudPalette.Green
            Status.DEGRADED -> NukeHudPalette.Amber
            Status.OFFLINE -> NukeHudPalette.MutedDeep
        }

        shell.rewind()
        shell.moveTo(cut, 0f)
        shell.lineTo(w - cut, 0f)
        shell.lineTo(w, cut)
        shell.lineTo(w - cut * .55f, h - cut * .40f)
        shell.lineTo(w * .5f, h)
        shell.lineTo(cut * .55f, h - cut * .40f)
        shell.lineTo(0f, cut)
        shell.close()
        fill.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(android.graphics.Color.rgb(9, 30, 20), android.graphics.Color.rgb(3, 12, 8)),
            null, Shader.TileMode.CLAMP,
        )
        c.drawPath(shell, fill)
        edge.color = withAlpha(accent, (105 + 125 * pulse).toInt())
        c.drawPath(shell, edge)

        val l = w * .29f
        val r = w * .71f
        val t = h * .24f
        val b = h * .75f
        val sw = w * .085f
        n.rewind()
        n.moveTo(l, t)
        n.lineTo(l + sw, t)
        n.lineTo(r - sw, b)
        n.lineTo(r, b)
        n.lineTo(r, t)
        n.lineTo(r - sw, t)
        n.lineTo(l + sw, b)
        n.lineTo(l, b)
        n.close()
        fill.shader = null
        fill.color = accent
        c.drawPath(n, fill)

        edge.color = withAlpha(
            if (status == Status.ONLINE) NukeHudPalette.Cyan else accent,
            (55 + 85 * pulse).toInt(),
        )
        edge.strokeWidth = 1.7f * d
        c.drawCircle(w * .5f, h * .5f, min(w, h) * (.34f + .02f * pulse), edge)
        edge.strokeWidth = 1f * d
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
}
