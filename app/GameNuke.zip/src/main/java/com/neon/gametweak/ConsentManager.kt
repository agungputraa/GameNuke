package com.neon.gametweak

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.ump.ConsentDebugSettings
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

object ConsentManager {
    private const val TAG = "ConsentManager"

    private val canRequestAdsFlag = AtomicBoolean(false)
    private val gatheringInFlight = AtomicBoolean(false)
    private val callbackLock = Any()
    private val pendingCallbacks = mutableListOf<(Boolean) -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun canRequestAds(): Boolean = canRequestAdsFlag.get()

    fun gatherConsent(activity: Activity, onComplete: (Boolean) -> Unit) {
        if (activity.isFinishing || activity.isDestroyed) {
            deliver(onComplete, canRequestAdsFlag.get())
            return
        }

        if (canRequestAdsFlag.get()) {
            deliver(onComplete, true)
            return
        }

        synchronized(callbackLock) { pendingCallbacks += onComplete }
        if (!gatheringInFlight.compareAndSet(false, true)) return

        try {
            val consentInformation = UserMessagingPlatform.getConsentInformation(activity)
            val params = if (BuildConfig.USE_TEST_ADS) {
                ConsentRequestParameters.Builder()
                    .setConsentDebugSettings(
                        ConsentDebugSettings.Builder(activity)
                            .setDebugGeography(ConsentDebugSettings.DebugGeography.DEBUG_GEOGRAPHY_EEA)
                            .build(),
                    )
                    .build()
            } else {
                ConsentRequestParameters.Builder().build()
            }

            consentInformation.requestConsentInfoUpdate(
                activity,
                params,
                {
                    try {
                        UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                            if (formError != null) {
                                Log.w(TAG, "Consent form error: ${formError.errorCode} ${formError.message}")
                            }
                            finishGathering(consentInformation.canRequestAds())
                        }
                    } catch (t: Throwable) {
                        Log.w(TAG, "Consent form invocation failed", t)
                        finishGathering(consentInformation.canRequestAds())
                    }
                },
                { requestError ->
                    Log.w(TAG, "Consent info request failed: ${requestError.errorCode} ${requestError.message}")
                    finishGathering(consentInformation.canRequestAds())
                },
            )
        } catch (t: Throwable) {
            Log.w(TAG, "Consent gathering failed", t)
            finishGathering(false)
        }
    }

    private fun finishGathering(canRequest: Boolean) {
        canRequestAdsFlag.set(canRequest)
        gatheringInFlight.set(false)
        val callbacks = synchronized(callbackLock) {
            pendingCallbacks.toList().also { pendingCallbacks.clear() }
        }
        callbacks.forEach { deliver(it, canRequest) }
        Log.d(TAG, "Consent state resolved: canRequestAds=$canRequest")
    }

    private fun deliver(callback: (Boolean) -> Unit, value: Boolean) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            runCatching { callback(value) }
        } else {
            mainHandler.post { runCatching { callback(value) } }
        }
    }

    fun reset(context: Context) {
        runCatching { UserMessagingPlatform.getConsentInformation(context).reset() }
        canRequestAdsFlag.set(false)
        gatheringInFlight.set(false)
        synchronized(callbackLock) { pendingCallbacks.clear() }
    }

    fun isPrivacyOptionsRequired(context: Context): Boolean = runCatching {
        UserMessagingPlatform.getConsentInformation(context).privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
    }.getOrDefault(false)

    fun showPrivacyOptionsForm(activity: Activity) {
        if (activity.isFinishing || activity.isDestroyed) return
        try {
            UserMessagingPlatform.showPrivacyOptionsForm(activity) { error ->
                if (error != null) {
                    Log.w(TAG, "Privacy options form error: ${error.errorCode} ${error.message}")
                }
                val refreshed = runCatching {
                    UserMessagingPlatform.getConsentInformation(activity).canRequestAds()
                }.getOrDefault(canRequestAdsFlag.get())
                canRequestAdsFlag.set(refreshed)
                if (refreshed) NukeAdManager.initialize(activity.applicationContext)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Privacy options form failed", t)
        }
    }
}
