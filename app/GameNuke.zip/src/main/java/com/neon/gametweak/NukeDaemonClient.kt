package com.neon.gametweak

import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.os.SystemClock
import android.util.Base64
import java.io.BufferedReader
import java.io.InputStreamReader

object NukeDaemonClient {
    const val SOCKET_NAME = "gamenuke.core.v1"
    @Volatile private var lastPingAt=0L
    @Volatile private var lastPing=false

    fun ping(force:Boolean=false):Boolean {
        val now=SystemClock.elapsedRealtime()
        if(!force && now-lastPingAt<1200L) return lastPing
        val ok=runCatching { request("PING",120) }.getOrNull()?.startsWith("PONG|")==true
        lastPingAt=now; lastPing=ok; return ok
    }

    fun execute(command:String, timeoutMs:Long=7500L, maxOutputChars:Int=131072):NukeCommandResult? {
        if(!NukeDaemonPolicy.isAllowed(command)) return null
        val payload=Base64.encodeToString(command.toByteArray(Charsets.UTF_8),Base64.NO_WRAP)
        val response=runCatching { request("EXEC|${timeoutMs.coerceIn(500,120000)}|$payload", (timeoutMs+1200).toInt().coerceAtMost(121000)) }.getOrNull() ?: return null
        val parts=response.split('|',limit=4)
        if(parts.size!=4 || parts[0]!="RESULT") return null
        val code=parts[1].toIntOrNull() ?: -1
        val timed=parts[2]=="1"
        val out=runCatching { String(Base64.decode(parts[3],Base64.NO_WRAP),Charsets.UTF_8) }.getOrDefault("").take(maxOutputChars)
        return NukeCommandResult(code,out,timed)
    }

    fun stop():Boolean {
        val ok=runCatching { request("STOP",1000).startsWith("BYE") }.getOrDefault(false)
        if(ok){ lastPing=false; lastPingAt=0L }
        return ok
    }

    private fun request(line:String, timeoutMs:Int):String {
        val socket=LocalSocket()
        try {
            socket.connect(LocalSocketAddress(SOCKET_NAME, LocalSocketAddress.Namespace.ABSTRACT), timeoutMs.coerceAtLeast(100))
            socket.soTimeout=timeoutMs.coerceAtLeast(100)
            val w=socket.outputStream.bufferedWriter(); w.write(line); w.write("\n"); w.flush()
            return BufferedReader(InputStreamReader(socket.inputStream)).readLine().orEmpty()
        } finally { runCatching { socket.close() } }
    }
}
