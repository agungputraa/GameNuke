package com.neon.gametweak

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import java.lang.ref.WeakReference

/**
 * Process bootstrap intentionally kept tiny. Expensive ADB discovery, consent/ads, integrity checks
 * and local-server creation are deferred until MainActivity has painted its first frame.
 */
class NukeApplication : Application(), Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {
    private var currentActivityRef: WeakReference<Activity>? = null

    override fun onCreate() {
        super<Application>.onCreate()
        registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        installCrashBreadcrumbGuard()

        // Language restore is cheap and avoids a visible text flip after the first frame.
        val prefs = getSharedPreferences("NukePrefs", MODE_PRIVATE)
        val code = prefs.safeString("hud_lang", "en")
            .takeIf { candidate -> Tx.supportedLangs.any { it.first == candidate } }
            ?: "en"
        Tx.setLang(code)
    }

    override fun onStart(owner: LifecycleOwner) {
        // kick() is a no-op until MainActivity has explicitly started the orchestrator.
        NukeAdbOrchestrator.kick("app-foreground")
        currentActivityRef?.get()?.let { activity ->
            if (activity is MainActivity && !activity.isFinishing && !activity.isDestroyed) {
                runCatching { NukeAdManager.showAppOpen(activity) }
            }
        }
    }

    override fun onActivityStarted(activity: Activity) { currentActivityRef = WeakReference(activity) }
    override fun onActivityResumed(activity: Activity) { currentActivityRef = WeakReference(activity) }
    override fun onActivityPaused(activity: Activity) = Unit
    override fun onActivityStopped(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
    override fun onActivityDestroyed(activity: Activity) {
        if (currentActivityRef?.get() === activity) currentActivityRef = null
    }

    /**
     * Records a tiny local breadcrumb before delegating to Android's original fatal handler.
     * We deliberately do not swallow uncaught exceptions: a corrupted process must terminate.
     * Runtime operations are expected to contain recoverable failures at their source.
     */
    private fun installCrashBreadcrumbGuard() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val file = java.io.File(filesDir, "last_fatal.txt")
                file.writeText(
                    buildString {
                        appendLine("time=${System.currentTimeMillis()}")
                        appendLine("thread=${thread.name}")
                        appendLine("type=${error.javaClass.name}")
                        appendLine("message=${error.message.orEmpty().take(500)}")
                    },
                )
            }
            if (previous != null) previous.uncaughtException(thread, error)
            else runCatching { android.os.Process.killProcess(android.os.Process.myPid()) }
        }
    }

}
