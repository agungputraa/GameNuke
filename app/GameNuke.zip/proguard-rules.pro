-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.gms.common.** { *; }

-keep class com.google.android.play.core.** { *; }
-keep interface com.google.android.play.core.** { *; }
-dontwarn com.google.android.play.core.**

-keep class com.neon.gametweak.IntegrityGuard { *; }

-keepclasseswithmembers class * {
    @androidx.annotation.Keep <methods>;
}
-keepclasseswithmembers class * {
    @androidx.annotation.Keep <fields>;
}
-keep @androidx.annotation.Keep class * { *; }

-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}



-keepattributes Signature, *Annotation*, EnclosingMethod, InnerClasses
-keep class kotlin.Metadata { *; }
-keep class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**

-keep class androidx.compose.runtime.** { *; }
-dontwarn androidx.compose.**

# --- ADB engine (pure Java) + crypto ---
# libadb-android: protocol + reflection-based TLS bootstrap.
-keep class io.github.muntashirakon.adb.** { *; }
# spake2-java: pairing handshake (pure Java).
-keep class io.github.muntashirakon.crypto.** { *; }
-dontwarn io.github.muntashirakon.**
# BouncyCastle (X509 cert gen). Provider/JCA pakai refleksi -> wajib keep.
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**
# Conscrypt is deliberately bundled for Wireless ADB pairing. libadb discovers it
# with reflection and calls exportKeyingMaterial(), so release shrinking must retain it.
-keep class org.conscrypt.** { *; }
-dontwarn org.conscrypt.**
# Referensi JDK yang tidak ada di Android (dipakai bcprov) -> abaikan saja.
-dontwarn javax.naming.**

# app_process entrypoint for the explicit user-authorized persistent local gaming core.
-keep class com.neon.gametweak.NukeShellDaemon {
    public static void main(java.lang.String[]);
}
