plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val releaseStoreFile = providers.gradleProperty("NUKE_RELEASE_STORE_FILE").orNull
val releaseStorePassword = providers.gradleProperty("NUKE_RELEASE_STORE_PASSWORD").orNull
val releaseKeyAlias = providers.gradleProperty("NUKE_RELEASE_KEY_ALIAS").orNull
val releaseKeyPassword = providers.gradleProperty("NUKE_RELEASE_KEY_PASSWORD").orNull
val hasReleaseSigning = listOf(releaseStoreFile, releaseStorePassword, releaseKeyAlias, releaseKeyPassword).all { !it.isNullOrBlank() }

android {
    namespace = "com.neon.gametweak"

    compileSdk = 36

    defaultConfig {
        applicationId = "com.neon.gametweak"
        minSdk = 30
        targetSdk = 36
        versionCode = 27
        versionName = "1.0.2"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
        ndk {
            abiFilters.add("arm64-v8a")
            abiFilters.add("armeabi-v7a")
        }
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseStoreFile!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            // Production must never use the Android debug key.
            signingConfig = signingConfigs.findByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")

            resValue("string", "admob_app_id",          "ca-app-pub-7865259628940934~3189989904")
            resValue("string", "admob_banner_id",       "ca-app-pub-7865259628940934/8945713610")
            resValue("string", "admob_interstitial_id", "ca-app-pub-7865259628940934/1021552179")
            resValue("string", "admob_app_open_id",     "ca-app-pub-7865259628940934/1412434411")

            buildConfigField("String", "ADMOB_BANNER_ID",       "\"ca-app-pub-7865259628940934/8945713610\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"ca-app-pub-7865259628940934/1021552179\"")
            buildConfigField("String", "ADMOB_APP_OPEN_ID",     "\"ca-app-pub-7865259628940934/1412434411\"")
            buildConfigField("boolean", "USE_TEST_ADS", "false")
        }
        debug {
            isMinifyEnabled = false
            isDebuggable = true

            resValue("string", "admob_app_id",          "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "admob_banner_id",       "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "admob_interstitial_id", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "admob_app_open_id",     "ca-app-pub-3940256099942544/9257395921")

            buildConfigField("String", "ADMOB_BANNER_ID",       "\"ca-app-pub-3940256099942544/9214589741\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"ca-app-pub-3940256099942544/1033173712\"")
            buildConfigField("String", "ADMOB_APP_OPEN_ID",     "\"ca-app-pub-3940256099942544/9257395921\"")
            buildConfigField("boolean", "USE_TEST_ADS", "true")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    lint {
        disable += setOf(
            "InvalidFragmentVersionForActivityResult",
            "MissingTranslation",
            "ExtraTranslation",
        )
        abortOnError = true
        checkReleaseBuilds = true
    }

    androidResources {
        noCompress += "mp4"
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/INDEX.LIST",
                "META-INF/DEPENDENCIES"
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.dynamicanimation:dynamicanimation-ktx:1.1.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-process:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.10.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.android.gms:play-services-ads:25.4.0")
    implementation("com.google.android.ump:user-messaging-platform:4.0.0")

    implementation("com.github.MuntashirAkon:libadb-android:3.1.1")
    // libadb pairing requires TLS 1.3 exporter support. Bundle Conscrypt instead of
    // reflecting into OEM/system Conscrypt, whose API surface differs between ROMs.
    implementation("org.conscrypt:conscrypt-android:2.5.3")
    implementation("org.bouncycastle:bcprov-jdk15to18:1.81")
    implementation("org.bouncycastle:bcpkix-jdk15to18:1.81")

    implementation("com.google.android.play:app-update:2.1.0")
    implementation("com.google.android.play:review:2.0.2")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.10.00"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}

val copyReleaseAab by tasks.registering(Copy::class) {
    from(layout.buildDirectory.dir("outputs/bundle/release"))
    include("*.aab")
    into(rootProject.layout.projectDirectory.dir("release-aab"))
}

tasks.configureEach {
    when (name) {
        "bundleRelease" -> finalizedBy(copyReleaseAab)
        "assembleRelease" -> finalizedBy("bundleRelease")
    }
}

tasks.register("productionAab") {
    dependsOn("bundleRelease")
}

tasks.register("aabRelease") {
    dependsOn("bundleRelease")
}
